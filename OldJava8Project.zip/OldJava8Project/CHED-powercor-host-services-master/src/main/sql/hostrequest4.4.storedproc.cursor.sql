-- Uses a function
CREATE OR REPLACE FUNCTION HOSTREQUEST_4_4F( in_postcode IN CHAR )
    RETURN SYS_REFCURSOR
AS
    st_cursor SYS_REFCURSOR;
BEGIN
    OPEN st_cursor FOR
        SELECT
            ORDER_ID,
            LOCALITY_ID,
            LOCALITY_NAME,
            POSTCODE,
            MESSAGE,
            CREW_STATUS,
            CUSTOMERS_AFFECTED,
            PLANNED,
            ETR,
            FAULTMEMO,
            POWERON_UPDATE
        FROM   IVR.IVR_OUTAGE_INFO
        WHERE  POSTCODE  = in_postcode and
            ( lower( crew_status ) != 'cancelled' and 
              lower( crew_status ) != 'field complete' and 
              lower( crew_status ) != 'closed' and 
              lower( crew_status ) != 'archived' )
        ORDER BY CUSTOMERS_AFFECTED DESC;
    RETURN  st_cursor;
END;


-- ORDER_ID	NUMBER (10)
-- LOCALITY_ID	NUMBER (10)
-- LOCALITY_NAME	VARCHAR2 (100 Byte)
-- POSTCODE	VARCHAR2 (4 Byte)
-- MESSAGE	VARCHAR2 (50 Byte)
-- CREW_STATUS	VARCHAR2 (16 Byte)
-- CUSTOMERS_AFFECTED	INTEGER	
-- PLANNED	INTEGER
-- ETR	DATE
-- FAULTMEMO	VARCHAR2 (200 Byte)
-- POWERON_UPDATE	INTEGER
