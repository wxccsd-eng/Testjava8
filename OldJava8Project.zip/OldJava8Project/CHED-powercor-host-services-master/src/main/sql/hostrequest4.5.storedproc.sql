-- Interim SP till we work out which table to use
CREATE OR REPLACE FUNCTION SMS.HOSTREQUEST_4_5F(
    theNMI IN VARCHAR2,
    theSmsMobile IN VARCHAR2,
    theDate IN DATE
)
RETURN NUMBER
AS
BEGIN
INSERT INTO IVR_SMS_PUSH (
    SEQ_NO,
    NMI,
    SMS_MOBILE,
    REQUEST_TIMESTAMP
) VALUES (
    ivr_sms_push_seq.nextval,
    theNMI,
    theSmsMobile,
    theDate
);
RETURN (1);
END;
