-- See email from Michael S dated 23rd May 2012
CREATE OR REPLACE FUNCTION HOSTREQUEST_4_9F( in_pcode IN CHAR )
    RETURN SYS_REFCURSOR
AS
    st_cursor SYS_REFCURSOR;
BEGIN
    OPEN st_cursor FOR
        SELECT  ORDER_ID                      ,
                LOCALITY_ID                   ,
                LOCALITY_NAME                 ,
                POSTCODE                      ,
                MESSAGE                       ,
                CREW_STATUS                   ,
                CUSTOMERS_AFFECTED            ,
                PLANNED                       ,
                ETR                           ,
                FAULTMEMO                    ,
                POWERON_UPDATE,
                MESSAGE_TYPE
        FROM
            IVR.IVR_OUTAGE_INFO_MANUAL
        WHERE
            POSTCODE= in_pcode;
    RETURN  st_cursor;
END;
