-- Uses a function
-- passing in as CHAR; if passing in as VARCHAR, need to use TRIM
CREATE OR REPLACE FUNCTION IVR.HOSTREQUEST_4_1F( in_cli IN CHAR )
    RETURN SYS_REFCURSOR
AS
    st_cursor SYS_REFCURSOR;
BEGIN
    OPEN st_cursor FOR
             SELECT DISTINCT
                 NO_TELEPHONE                  ,
                 NMI_NUMBER                    ,
                 TOWN                          ,
                 PCODE                         ,
                 STREET                        ,
                 UNIT                          ,
                 FLOOR                         ,
                 LOT                           ,
                 BLDG_NO                       ,
                 NM_PREFERRED                  ,
                 STATE                         ,
                 SERVPROVRESP_DT_START         ,
                 SERVPROVRESP_DT_END
             FROM   pcor_cli_details
             WHERE  no_telephone  = in_cli
                 AND SERVPROVRESP_DT_END IS NULL
              ORDER BY SERVPROVRESP_DT_START;
    RETURN  st_cursor;
END;


--CREATE OR REPLACE FUNCTION HOSTREQUEST_4_1F( in_cli IN CHAR )
--    RETURN SYS_REFCURSOR
--AS
--    st_cursor SYS_REFCURSOR;
--BEGIN
--    OPEN st_cursor FOR
--    SELECT
--           NMI_NUMBER                    ,
--           TOWN                          ,
--           PCODE                         ,
--           STREET                        ,
--           UNIT                          ,
--           FLOOR                         ,
--           LOT                           ,
--           BLDG_NO                       ,
--           NM_PREFERRED
--    FROM   pcor_cli_details
--    WHERE  no_telephone  = in_cli  ;
--    RETURN  st_cursor;
--END;

---- As above; but uses a procedure instead.
--CREATE OR REPLACE PROCEDURE HOSTREQUEST_4_1(
--    OUT_RESULT out SYS_REFCURSOR,
--    in_cli IN CHAR )
--AS
--BEGIN
--    OPEN OUT_RESULT FOR
--    SELECT
--           NO_TELEPHONE                  ,
--           NMI_NUMBER                    ,
--           TOWN                          ,
--           PCODE                         ,
--           STREET                        ,
--           UNIT                          ,
--           FLOOR                         ,
--           LOT                           ,
--           BLDG_NO                       ,
--           NM_PREFERRED                  ,
--           STATE
--    FROM   pcor_customer_details
--    WHERE  no_telephone  = in_cli  ;
--END;

-- As above; but uses a a synonym instead of table.

CREATE OR REPLACE PROCEDURE IVR.HOSTREQUEST_4_1(
    OUT_RESULT out SYS_REFCURSOR,
    in_cli IN CHAR )
AS
BEGIN
    OPEN OUT_RESULT FOR
            SELECT DISTINCT
                NO_TELEPHONE                  ,
                NMI_NUMBER                    ,
                TOWN                          ,
                PCODE                         ,
                STREET                        ,
                UNIT                          ,
                FLOOR                         ,
                LOT                           ,
                BLDG_NO                       ,
                NM_PREFERRED                  ,
                STATE                         ,
                SERVPROVRESP_DT_START         ,
                SERVPROVRESP_DT_END
            FROM   pcor_cli_details
            WHERE  no_telephone  = in_cli
                AND SERVPROVRESP_DT_END IS NULL
             ORDER BY SERVPROVRESP_DT_START;
END;




-- This is for Citypower
CREATE OR REPLACE PROCEDURE HOSTREQUEST_4_1_CP(
    OUT_RESULT out SYS_REFCURSOR,
    in_cli IN CHAR )
AS
BEGIN
    OPEN OUT_RESULT FOR
            SELECT DISTINCT
                NO_TELEPHONE                  ,
                NMI_NUMBER                    ,
                TOWN                          ,
                PCODE                         ,
                STREET                        ,
                UNIT                          ,
                FLOOR                         ,
                LOT                           ,
                BLDG_NO                       ,
                NM_PREFERRED                  ,
                STATE                         ,
                SERVPROVRESP_DT_START         ,
                SERVPROVRESP_DT_END
            FROM   cp_cli_details
            WHERE  no_telephone  = in_cli
                AND SERVPROVRESP_DT_END IS NULL
             ORDER BY SERVPROVRESP_DT_START;
END;

-- This is for ETSA
CREATE OR REPLACE PROCEDURE HOSTREQUEST_4_1_ETSA(
    OUT_RESULT out SYS_REFCURSOR,
    in_cli IN CHAR )
AS
BEGIN
    OPEN OUT_RESULT FOR
            SELECT DISTINCT
                NO_TELEPHONE                  ,
                NMI_NUMBER                    ,
                TOWN                          ,
                PCODE                         ,
                STREET                        ,
                UNIT                          ,
                FLOOR                         ,
                LOT                           ,
                BLDG_NO                       ,
                NM_PREFERRED                  ,
                STATE                         ,
                SERVPROVRESP_DT_START         ,
                SERVPROVRESP_DT_END
            FROM   etsa_cli_details
            WHERE  no_telephone  = in_cli
                AND SERVPROVRESP_DT_END IS NULL
             ORDER BY SERVPROVRESP_DT_START;
END;


---- To test, you can use the following
DECLARE 
  RetVal SYS_REFCURSOR;
  IN_CLI VARCHAR2(32767);
    NO_TELEPHONE CHAR(15);
    NMI_NUMBER VARCHAR2(30);
    TOWN VARCHAR2(30);
    PCODE CHAR(4);
    STREET VARCHAR2(137);
    UNIT VARCHAR2(101);
    FLOOR VARCHAR2(101);
    LOT VARCHAR2(20);
    BLDG_NO VARCHAR2(16);
    NM_PREFERRED VARCHAR2(60);
    STATE VARCHAR2(30);
    SERVPROVRESP_DT_END TIMESTAMP;
    SERVPROVRESP_DT_START TIMESTAMP;

BEGIN 
  IN_CLI := '0422437418';

  RetVal := IVR.HOSTREQUEST_4_1F( IN_CLI );
  dbms_output.put_line('b4 Rows: '||RetVal%ROWCOUNT);
  fetch RetVal into NO_TELEPHONE                  ,
                NMI_NUMBER                    ,
                TOWN                          ,
                PCODE                         ,
                STREET                        ,
                UNIT                          ,
                FLOOR                         ,
                LOT                           ,
                BLDG_NO                       ,
                NM_PREFERRED                  ,
                STATE;
  dbms_output.put_line('af Rows: '||RetVal%ROWCOUNT);

  COMMIT; 
END;

