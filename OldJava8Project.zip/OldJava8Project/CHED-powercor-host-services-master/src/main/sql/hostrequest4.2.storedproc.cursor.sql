-- Uses a function
CREATE OR REPLACE FUNCTION HOSTREQUEST_4_2F( in_pcode IN CHAR, in_town IN CHAR,
        in_street IN CHAR, in_lot IN CHAR, in_floor IN CHAR, in_unit IN CHAR,
         in_bldg_no IN CHAR )
    RETURN SYS_REFCURSOR
AS
    st_cursor SYS_REFCURSOR;
BEGIN
    OPEN st_cursor FOR
        SELECT DISTINCT 'None' as NO_TELEPHONE         ,
                NMI_NUMBER                    ,
                PCODE                         ,
                TOWN                          ,
                STREET                        ,
                UNIT                          ,
                FLOOR                         ,
                LOT                           ,
                BLDG_NO                       ,
                'None' as NM_PREFERRED,
                'None' as STATE
        FROM
            IVR.pcor_address_search
        WHERE
            lower(PCODE)= in_pcode
        and
            LOT = in_lot
        and
            FLOOR = in_floor
        and
            UNIT = in_unit
        and
            lower(BLDG_NO) = in_bldg_no
        and
            lower(TOWN) = in_town
        and
            lower(STREET) = in_street;
    RETURN  st_cursor;
END;

-- This is for Citypower
CREATE OR REPLACE FUNCTION HOSTREQUEST_4_2F( in_pcode IN CHAR, in_town IN CHAR,
        in_street IN CHAR, in_lot IN CHAR, in_floor IN CHAR, in_unit IN CHAR,
         in_bldg_no IN CHAR )
    RETURN SYS_REFCURSOR
AS
    st_cursor SYS_REFCURSOR;
BEGIN
    OPEN st_cursor FOR
        SELECT DISTINCT 'None' as NO_TELEPHONE         ,
                NMI_NUMBER                    ,
                PCODE                         ,
                TOWN                          ,
                STREET                        ,
                UNIT                          ,
                FLOOR                         ,
                LOT                           ,
                BLDG_NO                       ,
                'None' as NM_PREFERRED,
                'None' as STATE
        FROM
            IVR.cp_address_search
        WHERE
            lower(PCODE)= in_pcode
        and
            LOT = in_lot
        and
            FLOOR = in_floor
        and
            UNIT = in_unit
        and
            lower(BLDG_NO) = in_bldg_no
        and
            lower(TOWN) = in_town
        and
            lower(STREET) = in_street;
    RETURN  st_cursor;
END;

-- This is for ETSA
CREATE OR REPLACE FUNCTION HOSTREQUEST_4_2F( in_pcode IN CHAR, in_town IN CHAR,
        in_street IN CHAR, in_lot IN CHAR, in_floor IN CHAR, in_unit IN CHAR,
         in_bldg_no IN CHAR )
    RETURN SYS_REFCURSOR
AS
    st_cursor SYS_REFCURSOR;
BEGIN
    OPEN st_cursor FOR
        SELECT DISTINCT 'None' as NO_TELEPHONE         ,
                NMI_NUMBER                    ,
                PCODE                         ,
                TOWN                          ,
                STREET                        ,
                UNIT                          ,
                FLOOR                         ,
                LOT                           ,
                BLDG_NO                       ,
                'None' as NM_PREFERRED,
                'None' as STATE
        FROM
            IVR.etsa_address_search
        WHERE
            lower(PCODE)= in_pcode
        and
            LOT = in_lot
        and
            FLOOR = in_floor
        and
            UNIT = in_unit
        and
            lower(BLDG_NO) = in_bldg_no
        and
            lower(TOWN) = in_town
        and
            lower(STREET) = in_street;
    RETURN  st_cursor;
END;




-- Email from Allister dated 24th May
-- WHERE  pcd.BLDG_NO  = in_house_number + ‘-‘+ in_house_number2
--     AND    pcd.UNIT  = in_unit_type + ‘ ‘ + in_unit_number
--     AND    pcd.FLOOR  = in_level_type + ‘ ‘ + in_level_number
--     AND    pcd.LOT  = in_lot_number
--     AND    pcd.STREET  = in_street_name + ‘ ‘ + in_street_type+ ‘ ‘ + in_street_suffix
--     AND    pcd.TOWN  = in_suburb
--     AND    pcd.PCODE  = in_postcode;


-- ignoring 2) UNIT, FLOOR , LOT and BLDG_NO for now

-- NMI_NUMBER	1	VARCHAR2 (30 Byte)	Y
-- PCODE	2	VARCHAR2 (4 Byte)	N
-- TOWN	3	VARCHAR2 (30 Byte)	N
-- STREET	4	VARCHAR2 (137 Byte)	N
-- UNIT	5	VARCHAR2 (101 Byte)	Y
-- FLOOR	6	VARCHAR2 (101 Byte)	Y
-- LOT	7	VARCHAR2 (20 Byte)	Y
-- BLDG_NO	8	VARCHAR2 (16 Byte)	Y

---- To test, you can use the following

DECLARE 
  RetVal SYS_REFCURSOR;
    IN_PCODE VARCHAR2(30);
    IN_TOWN VARCHAR2(30);
    IN_STREET VARCHAR2(30);
    IN_BLDG_NO VARCHAR2(30);

    NO_TELEPHONE VARCHAR2(101);
    NMI_NUMBER VARCHAR2(30);
    TOWN VARCHAR2(30);
    STREET VARCHAR2(137);
    UNIT VARCHAR2(101);
    FLOORX VARCHAR2(101);
    LOT VARCHAR2(20);
    BLDG_NO VARCHAR2(16);
    PCODE CHAR(4);
    NM_PREFERRED VARCHAR2(101);
    STATE VARCHAR2(101);

BEGIN

  IN_PCODE := '3478';
  IN_TOWN := 'st arnaud';
  IN_STREET := 'queens avenue';
  IN_BLDG_NO := '25';

  RetVal := IVR.HOSTREQUEST_4_2F( IN_PCODE, IN_TOWN, IN_STREET, Null, Null, Null, IN_BLDG_NO );
  dbms_output.put_line('b4 Rows: '||RetVal%ROWCOUNT);
  fetch RetVal into
        NO_TELEPHONE         ,
        NMI_NUMBER                    ,
        PCODE                         ,
        TOWN                          ,
        STREET                        ,
        UNIT                          ,
        FLOORX                         ,
        LOT                           ,
        BLDG_NO                       ,
        NM_PREFERRED,
        STATE;
  dbms_output.put_line('nmi: '||NMI_NUMBER);

  COMMIT; 
END;
