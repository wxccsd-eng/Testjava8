package au.com.didata.powercor.services.repeatcaller.dao.jdbc;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import au.com.didata.powercor.services.repeatcaller.bean.RepeatCallerRecord;
import au.com.didata.powercor.services.repeatcaller.dao.RepeatCallerDao;

public class GetRepeatCallerJdbcDao implements RepeatCallerDao  {

    private static final Logger logger = Logger.getLogger(GetRepeatCallerJdbcDao.class);

    private String spGetRepeatCaller;
    private String spAddRepeatCaller;
    private JdbcTemplate jdbcTemplate;

    class GetRepeatCallerStoredProcedure extends StoredProcedure {
        private static final String ROUTERCALLKEY = "routerCallKey";
        private static final String ROUTERCALLKEYDAY = "routerCallKeyDay";
        private static final String CLI = "cli";
        private static final String DNIS = "dnis";
        private static final String CALLTYPE = "callType";
        private static final String NMI = "nmi";
        private static final String DISTRIBUTION_BUSINESS = "distributionBusiness";
        private static final String REPEAT_CALLS = "repeatCalls";

        public GetRepeatCallerStoredProcedure(DataSource dataSource, String sprocName) {
            super(dataSource, sprocName);


            declareParameter(new SqlOutParameter("rc", Types.INTEGER ));

            declareParameter(new SqlParameter(ROUTERCALLKEY, Types.INTEGER));
            declareParameter(new SqlParameter(ROUTERCALLKEYDAY,Types.INTEGER));
            declareParameter(new SqlParameter(DNIS,Types.VARCHAR));
            declareParameter(new SqlParameter(CLI, Types.VARCHAR));
            declareParameter(new SqlParameter(CALLTYPE, Types.VARCHAR));
            declareParameter(new SqlParameter(NMI,Types.VARCHAR));
            declareParameter(new SqlParameter(DISTRIBUTION_BUSINESS, Types.VARCHAR));
            declareParameter(new SqlParameter(REPEAT_CALLS, Types.INTEGER));

            setFunction(true); // need to set this if a function.

            compile();
        }

        public Map execute(String routerCallKey, String routerCallKeyDay,
                           String cli, String dnis, String callType, String nmi,
                           String distributionBusiness, Integer repeatCalls ) {

            int routerCallKeyInt = Integer.parseInt(routerCallKey);
            int routerCallKeyDayInt = Integer.parseInt(routerCallKeyDay);

            Map inputs = new HashMap();

            inputs.put(ROUTERCALLKEY, routerCallKeyInt);
            inputs.put(ROUTERCALLKEYDAY, routerCallKeyDayInt);
            inputs.put(DNIS, dnis);
            inputs.put(CLI, cli);
            inputs.put(CALLTYPE, callType);
            inputs.put(NMI, nmi);
            inputs.put(DISTRIBUTION_BUSINESS, distributionBusiness);
            inputs.put(REPEAT_CALLS, repeatCalls );

            return super.execute(inputs);
        }
    }


 //   @Override
    public int getRepeatCallers(String routerCallKey,
                                String routerCallKeyDay, String cli, String dnis, String callType,
                                String nmi, String distributionBusiness, Integer repeatCallers ) {

        Integer rc = 0;

        try {
            GetRepeatCallerStoredProcedure proc = new GetRepeatCallerStoredProcedure(
                    getJdbcTemplate().getDataSource(), spGetRepeatCaller);


            logger.debug("spGetRepeatCallers: " + routerCallKey + " " + routerCallKeyDay + " " + cli + " " + dnis + " " + callType + " " + nmi + " " + distributionBusiness);

            Map results = proc.execute(routerCallKey, routerCallKeyDay, cli, dnis,
                    callType, nmi, distributionBusiness, repeatCallers );
            rc = (Integer)results.get("rc");

            if (rc == null ) {
                // TODO - throw exception? or just record not found.
                logger.debug("Empty record set");
                return 0;
            }

            return rc;
        } catch(DataAccessException ex) {
            logger.error(ex.getMessage());
            throw ex;
        }
    }

    protected static final class RecordMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            RepeatCallerRecord record = new RepeatCallerRecord();

            ResultSetMetaData rsMetaData = rs.getMetaData();

            int columnCount = rsMetaData.getColumnCount();
            for (int i=1; i<=columnCount; i++) {
                logger.debug("Column:" + rsMetaData.getColumnName(i) + "=" + rs.getString(i) );

            }
            record.setCli(rs.getString(1));
            record.setDnis(rs.getString(2));
            record.setCallType(rs.getString(3));
            record.setNmi(rs.getString(4));
            record.setDatetime(rs.getString(5));
            record.setDistributionBusiness(rs.getString(6));

            return record;
        }
    }

    class InsertRepeatCallerStoredProcedure extends StoredProcedure {
        private static final String ROUTERCALLKEY = "routerCallKey";
        private static final String ROUTERCALLKEYDAY = "routerCallKeyDay";
        private static final String CLI = "cli";
        private static final String DNIS = "dnis";
        private static final String CALLTYPE = "callType";
        private static final String NMI = "nmi";
        private static final String DISTRIBUTION_BUSINESS = "distributionBusiness";
        private static final String REPEAT_CALLS = "repeatCalls";
        private static final String CALLDATE = "callDate";

        public InsertRepeatCallerStoredProcedure(DataSource dataSource, String sprocName) {
            super(dataSource, sprocName);


            declareParameter(new SqlOutParameter("rc", Types.INTEGER ));

            declareParameter(new SqlParameter(ROUTERCALLKEY, Types.INTEGER));
            declareParameter(new SqlParameter(ROUTERCALLKEYDAY,Types.INTEGER));
            declareParameter(new SqlParameter(CLI, Types.VARCHAR));
            declareParameter(new SqlParameter(DNIS,Types.VARCHAR));
            declareParameter(new SqlParameter(CALLTYPE, Types.VARCHAR));
            declareParameter(new SqlParameter(NMI,Types.VARCHAR));
            declareParameter(new SqlParameter(DISTRIBUTION_BUSINESS, Types.VARCHAR));
            declareParameter(new SqlParameter(CALLDATE, Types.TIMESTAMP ));

            setFunction(true); // need to set this if a function.

            compile();
        }

        public Map execute(int routerCallKey, int routerCallKeyDay,
                           String cli, String dnis, String callType, String nmi,
                           String distributionBusiness,
                           Date theDate ) {
            Map inputs = new HashMap();

            inputs.put(ROUTERCALLKEY, routerCallKey);
            inputs.put(ROUTERCALLKEYDAY, routerCallKeyDay);
            inputs.put(CLI, cli);
            inputs.put(DNIS, dnis);
            inputs.put(CALLTYPE, callType);
            inputs.put(NMI, nmi);
            inputs.put(DISTRIBUTION_BUSINESS, distributionBusiness);
            inputs.put(CALLDATE, theDate );

            return super.execute(inputs);
        }
    }

//    @Override
    public Integer insertRepeatCaller(int routerCallKey, int routerCallKeyDay,
                                      String cli, String dnis, String callType,
                                      String nmi, String distributionBusiness) {
        return insertRepeatCaller(routerCallKey, routerCallKeyDay, cli, dnis,
                callType, nmi, distributionBusiness, new Date() );
    }

    /**
     * this will be useful for creating test data.
     * @param routerCallKey
     * @param routerCallKeyDay
     * @param cli
     * @param dnis
     * @param callType
     * @param nmi
     * @param distributionBusiness
     * @param theDate
     * @return
     */
    public Integer insertRepeatCaller(int routerCallKey, int routerCallKeyDay,
                                      String cli, String dnis, String callType,
                                      String nmi, String distributionBusiness,
                                      Date theDate ) {
        Integer rc = null;

        try {
            InsertRepeatCallerStoredProcedure proc = new InsertRepeatCallerStoredProcedure(
                    getJdbcTemplate().getDataSource(), spAddRepeatCaller );

            Map results = proc.execute(routerCallKey, routerCallKeyDay, cli, dnis,
                    callType, nmi, distributionBusiness, theDate );
            rc = (Integer)results.get("rc");

            if (rc == null ) {
                // TODO - throw exception? or just record not found.
                logger.debug("Empty record set");
                return 0;
            }

            return rc;
        } catch(DataAccessException ex) {
            logger.error(ex.getMessage());
            throw ex;
        }
    }


    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public void setSpGetRepeatCaller(String spGetRepeatCaller) {
        this.spGetRepeatCaller = spGetRepeatCaller;
    }

    public void setSpAddRepeatCaller(String spAddRepeatCaller) {
        this.spAddRepeatCaller = spAddRepeatCaller;
    }

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }
}