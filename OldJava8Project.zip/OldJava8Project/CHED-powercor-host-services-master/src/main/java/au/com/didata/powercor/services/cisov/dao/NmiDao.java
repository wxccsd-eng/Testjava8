/**
 * Dimension Data Holdings plc. Confidential
 * 
 * Source Materials
 * 
 * RTA IVRCIMS Phase 1 - AU003203
 * 
 * Copyright (C) 2010 Dimension Data Holdings plc.
 * 
 * This library is confidential. No part of this library may be reproduced,
 * used or distributed for any purpose, without the prior written consent of Dimension 
 * Data Australia Pty Limited. This library is confidential and use, reproduction or 
 * distribution of this library or any part of it for any purpose, other than for 
 * selection of a supplier for the goods and/or services tendered, is STRICTLY PROHIBITED.
 *
 * $HeadURL$
 * $Id$ 
 */
package au.com.didata.powercor.services.cisov.dao;

import java.util.List;

import au.com.didata.powercor.services.cisov.bean.NmiRecord;

public interface NmiDao {

	public List<NmiRecord> getNmiRecords(String cli);
    public List<NmiRecord> getNmiRecordsGivenAddress(
//            String pcode,
//            String town,
//            String street,
            String houseNumber1,
            String houseNumber2,
            String houseNumberSuffix,
            String unitType,
            String unitNumber,
            String levelType,
            String levelNumber,
            String lotNumber,
            String streetName, /* this one */
            String streetType, /* this one */
            String streetSuffix, /* this one */
            String suburb, /* this one */
            String postcode, /* this one */
            String state );


}
