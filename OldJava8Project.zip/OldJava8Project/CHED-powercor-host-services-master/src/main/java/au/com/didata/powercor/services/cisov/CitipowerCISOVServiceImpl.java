package au.com.didata.powercor.services.cisov;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import au.com.didata.powercor.services.cisov.bean.NmiRecord;
import au.com.didata.powercor.services.cisov.dao.NmiDao;
import au.com.didata.powercor.services.cisov.dto.CustomerNMIResponseDTO;
import au.com.didata.powercor.services.exceptions.NoConnectionException;
import au.com.didata.powercor.services.exceptions.NoResponseException;
import au.com.didata.powercor.services.exceptions.PlatformErrorException;
import au.com.didata.powercor.services.exceptions.ServiceImplException;

public class CitipowerCISOVServiceImpl implements ICISOVService {

	static final Logger logger = Logger.getLogger(CitipowerCISOVServiceImpl.class);
	static final String VERSION = "0.0";
	
	//Actions
	public static final String ACTION_GET_NMI_FROM_CLI = "getNmiFromCLI";
	public static final String ACTION_GET_NMI_FROM_ADDRESS = "getNmiFromAddress";
	 
	// Request and response parameters
	private static final String PARAMETER_VERSION = "version";
	
	public static final int SUCCESS_CODE = 0;
	public static final int ERROR_CODE = -1;
	
	private NmiDao nmiDao;

	private boolean isEmpty(String s) {
		
		if (s == null || s.length() == 0)
			return true;
		else
			return false;
	}

	public List<CustomerNMIResponseDTO> getNMIFromCLI(String cli) throws NoConnectionException, NoResponseException, PlatformErrorException, ServiceImplException {

		
		if (logger.isInfoEnabled()) {
			
			logger.info("CISOV: getNmiFromCLI: " + "version=" + VERSION + ", cli=" + cli);
		}
		
		// TODO: This is where to call relevant services to get the host data

		List<CustomerNMIResponseDTO> responseList = new ArrayList<CustomerNMIResponseDTO>();
		CustomerNMIResponseDTO customerNmiResponse = new CustomerNMIResponseDTO();
		
		logger.info("Requesting records for cli:" + cli);	
		List<NmiRecord> recordList = null;
		
		try{
			recordList = nmiDao.getNmiRecords(cli);
		} catch (Exception e) {
			ServiceImplException se = new ServiceImplException("Unexpected error during execution of getNMIFromCLI() request", e);
			logger.error("Response exception", e);
			throw se;	
		}
		if (recordList != null && !recordList.isEmpty()) {
				
			int sizeOfList = recordList.size();
			for (int i=0; i<sizeOfList; i++) {
				
				NmiRecord record = recordList.get(i);
				logger.info("Record[" + i + "] = " + record.toString());	
				customerNmiResponse.setErrorCode(0);
				customerNmiResponse.setCustomerName(record.getNmPreferred());
				
				String houseNbr = "";
				if (record.getUnit() != null && record.getUnit().length() > 0) {
					houseNbr = record.getUnit();
				}			
				
				if (record.getLot() != null && record.getLot().length() > 0) {
					houseNbr = houseNbr + record.getLot();
				}
				
				if (record.getBldgNo() != null && record.getBldgNo().length() > 0) {
					houseNbr = houseNbr + " " + record.getBldgNo();
				}
				
				String streetNameAndType = "";
		
				if (record.getStreet() != null && record.getStreet().length() > 0) {
					streetNameAndType = record.getStreet();
				}
				logger.debug("streetNameAndType = " + streetNameAndType);
				
				customerNmiResponse.setHouseNumber(houseNbr);
				customerNmiResponse.setNmi(record.getNmi());
				customerNmiResponse.setPostcode(record.getPostCode());
				customerNmiResponse.setStreetNameAndType(streetNameAndType);
				customerNmiResponse.setSuburb(record.getSuburb());
					
				responseList.add(customerNmiResponse);
			}
		} else {
			// No record returned for CLI
			throw new NoResponseException(ERROR_CODE, "No NMI for CLI: " + cli);
		}
		
		return responseList;

	}
																
	public List<CustomerNMIResponseDTO> getNMIFromAddress(String houseNumber1, 
														  	String houseNumber2, 
														  	String houseNumberSuffix,
														  	String unitType, 
														  	String unitNumber, 
														  	String levelType,
														  	String levelNumber,
														  	String lotNumber,
														  	String streetName,
														  	String streetType,
														  	String streetSuffix,
														  	String suburb,
														  	String postcode,
														  	String state) throws NoConnectionException, NoResponseException, PlatformErrorException, ServiceImplException {

		if (logger.isInfoEnabled()) {
			
			logger.info("CISOV: getNMIFromAddress: " + "version=" + VERSION );
		}
		
		// TODO: This is where to call relevant services to get the host data
		
		List<CustomerNMIResponseDTO> responseList = new ArrayList<CustomerNMIResponseDTO>();
		CustomerNMIResponseDTO customerNmiResponse = new CustomerNMIResponseDTO();
		
		logger.debug("Requesting records for Address: houseNumber1=[" + houseNumber1 + "] houseNumber2=[" + houseNumber2 + "] unitType=[" + unitType + 
														"] unitNumber=[" + unitNumber + "] levelType=[" + levelType +"] levelNumber=[" + levelNumber + 
														"] lotNumber=[" + lotNumber + "] streetName=[" + streetName +"] streetType=[" + streetType + 
														"] streetSuffix=[" + streetSuffix + "] suburb=[" +  suburb + "] postcode=[" + postcode + 
														"] state=[" + state + "]");	
		List<NmiRecord> recordList = null;
		
		try{
			recordList = nmiDao.getNmiRecordsGivenAddress(houseNumber1, houseNumber2, houseNumberSuffix, unitType, unitNumber, levelType, levelNumber, lotNumber, streetName, streetType, streetSuffix, suburb, postcode, state);
		} catch (Exception e) {
			ServiceImplException se = new ServiceImplException("Unexpected error during execution of getNMIFromAddress() request", e);
			logger.error("Response exception", e);
			throw se;	
		}
		if (recordList != null && !recordList.isEmpty()) {
				
			int sizeOfList = recordList.size();
			for (int i=0; i<sizeOfList; i++) {
				
				NmiRecord record = recordList.get(i);
				logger.info("Record[" + i + "] = " + record.toString());	
				customerNmiResponse.setErrorCode(0);
				customerNmiResponse.setCustomerName(record.getNmPreferred());
				
				String houseNbr = "";
				
				if (record.getUnit() != null && record.getUnit().length() > 0) {
					houseNbr = record.getUnit();
				}		
				
				if (record.getFloor() != null && record.getFloor().length() > 0) {
					houseNbr = houseNbr + " " + record.getFloor();
				}
				
				if (record.getLot() != null && record.getLot().length() > 0) {
					houseNbr = houseNbr + record.getLot();
				}
				
				if (record.getBldgNo() != null && record.getBldgNo().length() > 0) {
					houseNbr = houseNbr + " " + record.getBldgNo();
				}
				
				String streetNameAndType = "";
		
				if (record.getStreet() != null && record.getStreet().length() > 0) {
					streetNameAndType = record.getStreet().trim();
				}
				logger.debug("streetNameAndType = " + streetNameAndType);
				
				customerNmiResponse.setHouseNumber(houseNbr.trim());
				customerNmiResponse.setNmi(record.getNmi());
				customerNmiResponse.setPostcode(record.getPostCode());
				customerNmiResponse.setStreetNameAndType(streetNameAndType);
				customerNmiResponse.setSuburb(record.getSuburb());
					
				responseList.add(customerNmiResponse);
			}
		} else {
			// No record returned for CLI
			throw new NoResponseException(ERROR_CODE, "No NMI for address with postcode: " + postcode);
		}
		
		return responseList;
		
	}
	
	public void setNmiDao(NmiDao nmiDao) {
		this.nmiDao = nmiDao;
	}
	
	public static void main(String[] args) {
		
			
	}
}
