package au.com.didata.powercor.services.playedmessages.dao;

import au.com.didata.powercor.services.playedmessages.bean.PlayedMessagesRecord;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: cang
 * Date: 15/05/12
 * Time: 3:14 PM
 * To change this template use File | Settings | File Templates.
 */
public interface IPlayedMessagesDao {
    public void insertPlayedMessages(int routerCallKey,int routerCallKeyDay,
                                      String cli, String nmi,
                                      String streetName, String streetType,
                                      String suburb1,
                                      String suburb2,
                                      String suburb3,
                                      String suburb4,
                                      String suburb5,
                                      String postCode,
                                      Date etr,
                                      String message,
                                      String crewStatus,
                                      Boolean manualMessage,
                                      String restoredStatus,
                                      Boolean error
    );

    public PlayedMessagesRecord getPlayedMessages(int routerCallKey,
                                                  int routerCallKeyDay,
                                                  Boolean theError);
}
