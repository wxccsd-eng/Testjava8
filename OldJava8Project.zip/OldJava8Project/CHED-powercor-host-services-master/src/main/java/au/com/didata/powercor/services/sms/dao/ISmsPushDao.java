/**
 * Dimension Data Holdings plc. Confidential
 * 
 * $HeadURL$
 * $Id$ 
 */
package au.com.didata.powercor.services.sms.dao;

import java.util.Date;

public interface ISmsPushDao {
    public Integer insertSmsPush( String theNmi, String theMobile,
                                  Date theDate );
    }