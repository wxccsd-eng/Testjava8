/**
 * Dimension Data Holdings plc. Confidential
 * 
 * Source Materials
 * 
 * RTA IVRCIMS Phase 1 - AU003203
 * 
 * Copyright (C) 2010 Dimension Data Holdings plc.
 * 
 * This library is confidential. No part of this library may be reproduced,
 * used or distributed for any purpose, without the prior written consent of Dimension 
 * Data Australia Pty Limited. This library is confidential and use, reproduction or 
 * distribution of this library or any part of it for any purpose, other than for 
 * selection of a supplier for the goods and/or services tendered, is STRICTLY PROHIBITED.
 *
 * $HeadURL$
 * $Id$ 
 */
package au.com.didata.powercor.services.repeatcaller.dao;

import java.util.Date;

public interface RepeatCallerDao {
	public int getRepeatCallers(String routerCallKey, String routerCallKeyDay,
                                String cli, String dnis, String callType,
                                String nmi, String distributionBusiness,
                                Integer repeatCallers );
	public Integer insertRepeatCaller(int routerCallKey,int routerCallKeyDay,
                                      String cli, String dnis, String callType,
                                      String nmi, String distributionBusiness);
    public Integer insertRepeatCaller(int routerCallKey, int routerCallKeyDay,
                                      String cli, String dnis, String callType,
                                      String nmi, String distributionBusiness,
                                      Date theDate);

}
