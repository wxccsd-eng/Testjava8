/**
 * Dimension Data Holdings plc. Confidential
 * 
 * Source Materials
 * 
 * Powercor
 * 
 * Copyright (C) 2010 Dimension Data Holdings plc.
 * 
 * This library is confidential. No part of this library may be reproduced,
 * used or distributed for any purpose, without the prior written consent of Dimension 
 * Data Australia Pty Limited. This library is confidential and use, reproduction or 
 * distribution of this library or any part of it for any purpose, other than for 
 * selection of a supplier for the goods and/or services tendered, is STRICTLY PROHIBITED.
 *
 * $HeadURL$
 * $Id$ 
 */
package au.com.didata.powercor.services.repeatcaller.bean;

import java.io.Serializable;

import org.apache.log4j.Logger;

public class RepeatCallerRecord implements Serializable {
	
	/**
	 * 
	 */
	private static long serialVersionUID = 1L;

	private static Logger logger = Logger.getLogger("RepeatCallerRecord.class");


	String cli;
	String dnis;
	String callType;
	String nmi;
	String datetime;
	

	String distributionBusiness;






	public String getCli() {
		return cli;
	}




	public void setCli(String cli) {
		this.cli = cli;
	}




	public String getDnis() {
		return dnis;
	}




	public void setDnis(String dnis) {
		this.dnis = dnis;
	}




	public String getCallType() {
		return callType;
	}




	public void setCallType(String callType) {
		this.callType = callType;
	}




	public String getNmi() {
		return nmi;
	}




	public void setNmi(String nmi) {
		this.nmi = nmi;
	}




	public String getDistributionBusiness() {
		return distributionBusiness;
	}




	public void setDistributionBusiness(String distributionBusiness) {
		this.distributionBusiness = distributionBusiness;
	}


	public String getDatetime() {
		return datetime;
	}




	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}

	public String toString() {
		return new StringBuffer("RepeatCallerRecord: ").
					append(" CLI=").append(getCli()).
					append(" DNIS=").append(getDnis()).
					append(" CallType=").append(getCallType()).
					append(" NMI=").append(getNmi()).
					append(" Datetime=").append(getDatetime()).
					append(" DistributionBusiness=").append(getDistributionBusiness()).

					toString();
		
	}
}
