package au.com.didata.powercor.services.playedmessages;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import au.com.didata.powercor.services.exceptions.NoConnectionException;
import au.com.didata.powercor.services.exceptions.NoResponseException;
import au.com.didata.powercor.services.exceptions.PlatformErrorException;
import au.com.didata.powercor.services.exceptions.ServiceImplException;
import au.com.didata.powercor.services.playedmessages.bean.PlayedMessagesRecord;
import au.com.didata.powercor.services.playedmessages.dao.IPlayedMessagesDao;
import au.com.didata.powercor.services.playedmessages.dto.PlayedMessagesResponseDTO;
import au.com.didata.powercor.services.playedmessages.dto.StoreMessagesResponseDTO;

public class PlayedMessagesServiceImpl implements IPlayedMessagesService {

	static final Logger logger = Logger.getLogger(PlayedMessagesServiceImpl.class);
	static final String VERSION = "0.0";
	
	public static final int SUCCESS_CODE = 0;
	public static final int ERROR_CODE = -1;
	
	// Actions
	public static final String ACTION_STORE_MESSAGES = "playedMessages";

	// Request and response parameters
	private static final String PARAMETER_VERSION = "version";
	
    private IPlayedMessagesDao iPlayedMessagesDao;
	

	private boolean isEmpty(String s) {
		
		if (s == null || s.length() == 0)
			return true;
		else
			return false;
	}
	
	/**
	 * Helper method used to format a string where sensitive data can be blocked if required
	 * 
	 * @param  query
	 * @throws IllegalArgumentException		if input argument is null
	 * @return String
	 * @throws 
	 */
	protected String logQueryString(String query) {
	
		return query;			
	}
	
	public static void main(String[] args) {
		
			
	}

	public StoreMessagesResponseDTO storeMessagesPlayed(
			String routerCallKey, String routerCallKeyDay,
			String cli, String nmi, String streetName, String streetType,
			String suburb1, String suburb2, String suburb3, String suburb4,
			String suburb5, String postCode, String etr, String message, String crewStatus,
			String manualMessageFlag, String restoredStatus) throws  NoConnectionException, NoResponseException, PlatformErrorException, ServiceImplException  {

		if (logger.isInfoEnabled()) {
			
			logger.info("StoreMessages: storeMessagesPlayed: " + "version=" + VERSION );
		}
		
		// TODO: This is where to call relevant services to get the host data
		logger.debug("storeMessagesPlayed: RCK=" + routerCallKey + " RCD=" + routerCallKeyDay + " cli=" + cli + " nmi=" + nmi + " streetName=" + streetName + " streetType=" + streetType + " suburb1=" + suburb1 + " suburb2=" + suburb2 +" suburb3=" + suburb3 +" suburb4=" + suburb4 +" suburb5=" + suburb5 + " postCode=" + postCode + " etr=" + etr + " message=" + message + " crewStatus=" + crewStatus + " manualMessageFlag=" + manualMessageFlag); 
		StoreMessagesResponseDTO response = new StoreMessagesResponseDTO();
		

		
		try {
			// Date convertedDate = new Date(0);
			Date convertedDate = null;
			
			if (etr != null && etr.length() > 0) {
				
				// Convert ETR string to Date
				// Example format 2012-04-27 17:30:00.0
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
				
				convertedDate = sdf.parse(etr);
				
				String formattedEtr = sdf.format(convertedDate);
				logger.debug("formatted time" + formattedEtr + " tz=" + sdf.getTimeZone().getDisplayName());
			}
			
			iPlayedMessagesDao.insertPlayedMessages(Integer.parseInt(routerCallKey), Integer.parseInt(routerCallKeyDay), cli, nmi, streetName, streetType, suburb1, suburb2, suburb3, suburb4, suburb5, postCode, convertedDate, message, crewStatus, Boolean.parseBoolean(manualMessageFlag), restoredStatus, true);

			 response.setErrorCode(SUCCESS_CODE);
		} catch (NumberFormatException nfe) {
			PlatformErrorException pe = new PlatformErrorException(ERROR_CODE, nfe.getMessage());
			logger.error("NumberFormatException", pe);
			throw pe;
		} catch (Exception e) {
			ServiceImplException se = new ServiceImplException("Unexpected error during execution of storeMessagesPlayed() request", e);
			logger.error("Response exception", e);
			throw se;	
		}
		
		// Set default error code 0
		response.setErrorCode(0);

			
		return response;
	
	}

//	@Override
	public PlayedMessagesResponseDTO getPlayedMessages(String routerCallKey, String routerCallKeyDay) throws NoConnectionException, NoResponseException, PlatformErrorException, ServiceImplException {
	if (logger.isInfoEnabled()) {
			
			logger.info("PlayedMessages: getPlayedMessages: " + "version=" + VERSION );
		}
		
		// TODO: This is where to call relevant services to get the host data
		logger.debug("getMessagesPlayed: RCK=" + routerCallKey + " RCD=" + routerCallKeyDay);
		PlayedMessagesResponseDTO response = new PlayedMessagesResponseDTO();
		
		try{
			
			PlayedMessagesRecord record = iPlayedMessagesDao.getPlayedMessages(Integer.parseInt(routerCallKey), Integer.parseInt(routerCallKeyDay), true);
			if (record != null) {
				response.setDateTime(record.getCallDate().toString());
				response.setCli(record.getCli());
				response.setNmi(record.getNmi());
				response.setStreetName(record.getStreetName());
				response.setStreetType(record.getStreetType());
				response.setSuburb1(record.getSuburb1());
				response.setSuburb2(record.getSuburb2());
				response.setSuburb3(record.getSuburb3());
				response.setSuburb4(record.getSuburb4());
				response.setSuburb5(record.getSuburb5());
				if (record.getEtr() != null) {
					response.setEtr(record.getEtr().toString());
				} else {
					response.setEtr(null);
				}
				response.setMessage(record.getMessage());
				response.setCrewStatus(record.getCrewStatus());
				response.setManualMessage(record.getManualMessage().toString());
				response.setPostCode(record.getPostCode());
				response.setRestoredStatus(record.getRestoredStatus());
				response.setErrorCode(SUCCESS_CODE);
				
				logger.debug("PlayedMessagesRecord = " + record.toString());
			} else {
				// No record returned for CLI
				throw new NoResponseException(ERROR_CODE, "No played messages for rck=: " + routerCallKey + " rcd=" + routerCallKeyDay);
			}
		} catch (Exception e) {
			ServiceImplException se = new ServiceImplException("Unexpected error during execution of storeMessagesPlayed() request", e);
			logger.error("Response exception", e);
			throw se;	
		}
		
		// Set default error code 0
		response.setErrorCode(0);
			
		return response;
	}
	
	
	
	public void setPlayedMessagesDao(IPlayedMessagesDao iPlayedMessagesDao) {
		this.iPlayedMessagesDao = iPlayedMessagesDao;
	}

}
