package au.com.didata.powercor.services.cisov.dao.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import oracle.jdbc.internal.OracleTypes;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import au.com.didata.powercor.services.cisov.bean.NmiRecord;
import au.com.didata.powercor.services.cisov.dao.NmiDao;
import au.com.didata.powercor.services.outages.bean.IvrOutageInfoRecord;

public class UneNmiJdbcDao implements NmiDao  {

    private static final Logger logger = Logger.getLogger(UneNmiJdbcDao.class);

    private String nmiByCliStoredProc;
    private String nmiByAddressStoredProc;
    private JdbcTemplate jdbcTemplate;

    class NmiStoredProcedure extends StoredProcedure {
        private static final String CLI = "cli";

        public NmiStoredProcedure(DataSource dataSource, String sprocName) {
            super(dataSource, sprocName);

            declareParameter(new SqlOutParameter("rs", OracleTypes.CURSOR, new RecordMapper()));
            declareParameter(new SqlParameter(CLI, OracleTypes.VARCHAR));
            compile();
        }

        public Map execute(String cli) {
            Map inputs = new HashMap();
            inputs.put(CLI, cli);
            return super.execute(inputs);
        }
    }


    class NmiGivenAddressStoredProcedure extends StoredProcedure {
        private static final String CLI = "cli";

        public NmiGivenAddressStoredProcedure(DataSource dataSource, String sprocName) {
            super(dataSource, sprocName);

            declareParameter(new SqlOutParameter("rs", OracleTypes.CURSOR, new RecordMapper()));

            declareParameter(new SqlParameter( "PCODE", OracleTypes.CHAR));
            declareParameter(new SqlParameter( "TOWN", OracleTypes.CHAR));
            declareParameter(new SqlParameter( "STREET", OracleTypes.CHAR));
            declareParameter(new SqlParameter("LOT", OracleTypes.CHAR));
            declareParameter(new SqlParameter("FLOOR", OracleTypes.CHAR));
            declareParameter(new SqlParameter("UNIT", OracleTypes.CHAR));
            declareParameter(new SqlParameter("BLDG_NO", OracleTypes.CHAR));
            // http://stackoverflow.com/questions/862694/how-to-call-oracle-function-or-stored-procedure-using-spring-persistence-framewo
            setFunction(true); // need to set this if a function.
            compile();
            
         }
     
        public Map execute( String postcode,
                            String town_suburb,
                            String street,
                            String lotNumber,
                            String floor,
                            String unit,
                            String bldg_no ) {
            Map inputs = new HashMap();
//            -- NMI_NUMBER	1	VARCHAR2 (30 Byte)	Y
//                    -- PCODE	2	VARCHAR2 (4 Byte)	N
//                    -- TOWN	3	VARCHAR2 (30 Byte)	N
//                    -- STREET	4	VARCHAR2 (137 Byte)	N
//                    -- UNIT	5	VARCHAR2 (101 Byte)	Y
//                    -- FLOOR	6	VARCHAR2 (101 Byte)	Y
//                    -- LOT	7	VARCHAR2 (20 Byte)	Y
//                    -- BLDG_NO	8	VARCHAR2 (16 Byte)	Y

            inputs.put( "PCODE", postcode);
            inputs.put( "TOWN", town_suburb );
            inputs.put( "STREET", street );
            inputs.put( "UNIT", unit );
            inputs.put( "FLOOR", floor );
            inputs.put( "LOT", lotNumber );
            inputs.put( "BLDG_NO", bldg_no );
            return super.execute(inputs);
        }
    }

    public List<NmiRecord> getNmiRecords(String cli) {
        List<NmiRecord> records = null;
        if (logger.isInfoEnabled()) logger.info(String.format("UNE: Entering getNmiRecords: cli=[%s], StoredProc=[%s]", cli, nmiByCliStoredProc));
        try {
            NmiStoredProcedure proc = new NmiStoredProcedure(
                    getJdbcTemplate().getDataSource(), nmiByCliStoredProc);

            Map results = proc.execute(cli);
            records = (List)results.get("rs");

            if (records == null || records.isEmpty()) {
                if (logger.isInfoEnabled()) logger.info(String.format("UNE: Exiting getNmiRecords: no records found: cli=%s", cli));
            	return null;
            }
            if (logger.isInfoEnabled()) logger.info(String.format("UNE: Exiting getNmiRecords: records=%s", Arrays.toString(records.toArray())));
            return records;
        } catch(DataAccessException ex) {
            logger.error(String.format("UNE: getNmiRecords: Exception thrown: %s", ex.getMessage()));
            throw ex;
        }
    }

    /**
     * Current implementation only takes in
     * postcode, suburb and street name
     */
    public List<NmiRecord> getNmiRecordsGivenAddress(
            String houseNumber1,
            String houseNumber2,
            String houseNumberSuffix,
            String unitType,
            String unitNumber,
            String levelType,
            String levelNumber,
            String lotNumber,
            String streetName,
            String streetType,
            String streetSuffix,
            String suburb,
            String postcode,
            String state ) {
        // see email from Allister, dated 25th May 2012. cc'd vonita
        String pcode = postcode;
        String town = suburb;
        String street = streetName + " " + streetType + " " + streetSuffix;
        street = street.trim(); // get rid of trailing spaces.
        
        String floor = "";
        if (levelNumber != null) {
        	floor = levelNumber;
        	floor = floor.trim();
        }
        
        String unit = "";
        
        if (unitNumber != null) {
        	unit = unitNumber;
        	unit = unit.trim();
        }
        
        String bldg_no = houseNumber1;
        if ( houseNumberSuffix != null && houseNumberSuffix.trim().length() > 0 ) {
        	bldg_no = houseNumber1 + houseNumberSuffix;
        }
        
        if ( houseNumber2 != null && houseNumber2.trim().length() > 0 ) {
            bldg_no = houseNumber1 + "-" + houseNumber2; // USE OF DASH!
            bldg_no = bldg_no.trim();
        }

        return getNmiRecordsGivenAddress(
                pcode,
                town,
                street,
                lotNumber,
                floor,
                unit,
                bldg_no);
    }

    /**
     * Helper method to HostRequest4.2 to return only unique NMIs
     */
    private List<NmiRecord> getUniqueRecordPerNMI(List<NmiRecord> recordIvrs) {
    	   
    	List<NmiRecord> uniqueRecordList = null;
    	 
    	if (recordIvrs != null) {
    	    
    		List<String> nmiSet = new ArrayList<String>();
    	    String nmi = null;
    	   
    	    uniqueRecordList = new ArrayList<NmiRecord>();
    	    for (NmiRecord row : recordIvrs ) {
    	    	nmi = row.getNmi();
    	        if ( !nmiSet.contains(nmi)) {
    	        	nmiSet.add(nmi);
    	            uniqueRecordList.add(row);
    	         }
    	    }
    	}
    	return uniqueRecordList;
   }
    
    public List<NmiRecord> getNmiRecordsGivenAddress(String pcode,
                                                     String town,
                                                     String street,
                                                     String lotNumber,
                                                     String floor,
                                                     String unit,
                                                     String bldg_no ) {
        List<NmiRecord> records = null;
        try {
        	if(logger.isInfoEnabled()) logger.info(String.format("UNE: Entering getNmiRecordsGivenAddress: Postcode=[%s],StoredProc=[%s]", pcode,nmiByAddressStoredProc));
            NmiGivenAddressStoredProcedure proc = new NmiGivenAddressStoredProcedure(
                    getJdbcTemplate().getDataSource(), nmiByAddressStoredProc);

            logger.debug("getNMIRecordsGivenAddress pcode=[" + pcode + 
            											"] town=[" + town + 
            											"] street=[" + street + 
            											"] lotNumber=[" + lotNumber +
            											"] floor=[" + floor + 
            											"] unit=[" + unit + 
            											"] bldg_no=[" + bldg_no + "]");
            Map results = proc.execute(
                    pcode,
                    town,
                    street,
                    lotNumber,
                    floor,
                    unit,
                    bldg_no);

            //records = (List)results.get("rs");
            logger.debug("nmi by address records = " + (List)results.get("rs"));
            records = getUniqueRecordPerNMI( (List)results.get("rs"));
            
            if (records == null || records.isEmpty()) {
            	if(logger.isInfoEnabled()) logger.info(String.format("UNE: Exiting getNmiRecordsGivenAddress: No records returned"));
            	return null;
            }
        	if(logger.isInfoEnabled()) logger.info(String.format("UNE: Exiting getNmiRecordsGivenAddress: records=%s", Arrays.toString(records.toArray())));

            return records;
        } catch(DataAccessException ex) {
            logger.error(String.format("UNE: getNmiRecordsGivenAddress: DataAccessException thrown: %s", ex.getMessage()));
            throw ex;
        }
    }

    protected static final class RecordMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        	
            NmiRecord nmiRecord = new NmiRecord();

            nmiRecord.setTelephoneNo((rs.getString(1)));
            nmiRecord.setNmi((rs.getString(2)));
            nmiRecord.setSuburb((rs.getString(3)));
            nmiRecord.setPostCode((rs.getString(4)));
            nmiRecord.setStreet((rs.getString(5)));
            nmiRecord.setUnit((rs.getString(6)));
            nmiRecord.setFloor((rs.getString(7)));
            nmiRecord.setLot((rs.getString(8)));
            nmiRecord.setBldgNo((rs.getString(9)));
            nmiRecord.setNmPreferred((rs.getString(10)));
            nmiRecord.setState((rs.getString(11)));

            return nmiRecord;
        }
    }

    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public void setNmiByCliStoredProc(String nmiByCliStoredProc) {
        this.nmiByCliStoredProc = nmiByCliStoredProc;
    }

    public void setNmiByAddressStoredProc(String nmiByAddressStoredProc) {
        this.nmiByAddressStoredProc = nmiByAddressStoredProc;
    }

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

}