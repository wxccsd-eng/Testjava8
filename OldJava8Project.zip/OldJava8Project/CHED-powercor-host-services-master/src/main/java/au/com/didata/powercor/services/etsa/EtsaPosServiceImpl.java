package au.com.didata.powercor.services.etsa;

import java.util.List;

import org.apache.log4j.Logger;

import au.com.didata.powercor.services.cisov.dao.NmiDao;
import au.com.didata.powercor.services.etsa.dao.IEtsaIvrOutageDao;

import au.com.didata.powercor.services.etsapos.IEtsaPosService;
import au.com.didata.powercor.services.etsapos.dto.EtsaOutageByNmiResponseDTO;
import au.com.didata.powercor.services.etsapos.dto.EtsaOutageByPostcodeResponseDTO;
import au.com.didata.powercor.services.etsapos.dto.EtsaPostcodeOutageRecord;
import au.com.didata.powercor.services.exceptions.NoConnectionException;
import au.com.didata.powercor.services.exceptions.NoResponseException;
import au.com.didata.powercor.services.exceptions.PlatformErrorException;
import au.com.didata.powercor.services.exceptions.ServiceImplException;
import au.com.didata.powercor.services.oms.dto.OutageByPostcodeResponseDTO;

public class EtsaPosServiceImpl implements IEtsaPosService {

	static final Logger logger = Logger.getLogger(EtsaPosServiceImpl.class);
	static final String VERSION = "0.0";
	
	//Actions
	public static final String ACTION_GET_NMI_FROM_CLI = "getNmiFromCLI";
	public static final String ACTION_GET_NMI_FROM_ADDRESS = "getNmiFromAddress";
	 
	// Request and response parameters
	private static final String PARAMETER_VERSION = "version";
	
	public static final int SUCCESS_CODE = 0;
	public static final int ERROR_CODE = -1;
	
	private IEtsaIvrOutageDao ivrOutageWS;



//	@Override
	public EtsaOutageByNmiResponseDTO getOutagesByNMI(String nmi)
			throws NoConnectionException, NoResponseException,
			PlatformErrorException, ServiceImplException {
		
		EtsaOutageByNmiResponseDTO response = new EtsaOutageByNmiResponseDTO();
	
		
		logger.debug("Requesting ETSA Outage for NMI: " + nmi);	
		
		try{
			 response = ivrOutageWS.getOutagesByNmi(nmi);
			 if (response == null) {
				// No record returned for NMI
				throw new NoResponseException(ERROR_CODE, "No ETSA Outage for NMI: " + nmi);
			 }
			 response.setErrorCode(SUCCESS_CODE);
		} catch (Exception e) {
			ServiceImplException se = new ServiceImplException("Unexpected error during execution of getOutagesForNmi() request", e);
			logger.error("Response exception", e);
			throw se;	
		}

		return response;
	}

//	@Override
	public EtsaOutageByPostcodeResponseDTO getOutagesByPostcode(
			String postcode) throws NoConnectionException, NoResponseException,
			PlatformErrorException, ServiceImplException {
		
		EtsaOutageByPostcodeResponseDTO postcodeOutageResponse = new EtsaOutageByPostcodeResponseDTO();		
 		
		// Set default error code 0
		postcodeOutageResponse.setErrorCode(0);
	
	/*	EtsaPostcodeOutageRecord record = new EtsaPostcodeOutageRecord();
		record.setSuburb("abbott_lane");
		record.setReason("00");
		record.setStage("11");
		record.setEtr("20/06/2012 19:55:27");
		record.setEtrKnown("1");
		record.setRestoredStatus("1");
		
		postcodeOutageResponse.addRecord(record);
		
		record.setSuburb("boston");
		record.setReason("00");
		record.setStage("11");
		record.setEtr("20/06/2012 08:06:27");
		record.setEtrKnown("2");
		record.setRestoredStatus("0");

		postcodeOutageResponse.addRecord(record);
		
		record.setSuburb("virginia");
		record.setReason("00");
		record.setStage("11");
		record.setEtr("20/06/2012 12:30:27");
		record.setEtrKnown("2");
		record.setRestoredStatus("1");

		postcodeOutageResponse.addRecord(record);
		
		return postcodeOutageResponse;		
		*/

		EtsaOutageByPostcodeResponseDTO response = new EtsaOutageByPostcodeResponseDTO();
	
		
		logger.debug("Requesting ETSA Outage for Postcode: " + postcode);	
		
		try{
			 response = ivrOutageWS.getOutagesByPostcode(postcode);
			 if (response == null) {
				// No record returned for NMI
				throw new NoResponseException(ERROR_CODE, "No ETSA Outage for Postcode: " + postcode);
			 }
			 response.setErrorCode(SUCCESS_CODE);
		} catch (Exception e) {
			ServiceImplException se = new ServiceImplException("Unexpected error during execution of getOutagesForPostcode() request", e);
			logger.error("Response exception", e);
			throw se;	
		}

		return response;


	}
	
	public void setIvrOutageWS(IEtsaIvrOutageDao ivrOutageWS) {
		this.ivrOutageWS = ivrOutageWS;
	}
	
	public static void main(String[] args) {

	}
}
