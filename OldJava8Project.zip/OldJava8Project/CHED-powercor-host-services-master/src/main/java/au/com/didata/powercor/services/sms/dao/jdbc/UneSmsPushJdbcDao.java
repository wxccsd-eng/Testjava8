package au.com.didata.powercor.services.sms.dao.jdbc;

import au.com.didata.powercor.services.sms.dao.ISmsPushDao;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class UneSmsPushJdbcDao implements ISmsPushDao {

    private static final Logger logger = Logger.getLogger(UneSmsPushJdbcDao.class);

    private static final String NMI = "NMI";
    private static final String SMS_MOBILE = "SMS_MOBILE";
    private static final String REQUEST_TIMESTAMP = "REQUEST_TIMESTAMP";

    private String spInsertSmsPush;
    private JdbcTemplate jdbcTemplate;

    class InsertSmsPushStoredProcedure extends StoredProcedure {
        public InsertSmsPushStoredProcedure (DataSource dataSource, String sprocName) {
            super(dataSource, sprocName);
            declareParameter(new SqlOutParameter("rc", Types.INTEGER ));

            declareParameter(new SqlParameter( NMI, Types.VARCHAR));
            declareParameter(new SqlParameter( SMS_MOBILE, Types.VARCHAR));
            declareParameter(new SqlParameter( REQUEST_TIMESTAMP, Types.TIMESTAMP ));

            setFunction(true); // need to set this if a function.

            compile();
        }

        public Map execute( String theNmi,
                            String theMobileNumber, Date theDate ) {
            Map inputs = new HashMap();

            inputs.put( NMI, theNmi );
            inputs.put( SMS_MOBILE, theMobileNumber );
            inputs.put( REQUEST_TIMESTAMP, theDate );

            return super.execute(inputs);
        }
    }

    public Integer insertSmsPush( String theNmi, String theMobile,
                                  Date theDate ) {
        Integer rc = null;
        try {
        	if (logger.isInfoEnabled()) logger.info(String.format("Entering insertSmsPush UNE:mobile=[%s], date=[%s], storedProc=[%s]", theMobile, theDate,spInsertSmsPush));
        	
            InsertSmsPushStoredProcedure proc = new InsertSmsPushStoredProcedure(getJdbcTemplate().getDataSource(), spInsertSmsPush );

            Map results = proc.execute( theNmi, theMobile, theDate );
            rc = (Integer)results.get("rc");

            if (rc == null ) {
                if (logger.isDebugEnabled()) logger.debug("insertSmsPush (UNE): Empty record set");
                return 0;
            }
            if (logger.isDebugEnabled()) logger.debug(String.format("insertSmsPush (UNE): returning: %s", rc));

            return rc;
        } catch(DataAccessException ex) {
            logger.error(String.format("insertSmsPush (UNE) threw exception: %s",ex.getMessage()));
            throw ex;
        }
    }

    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setSpInsertSmsPush(String spInsertSmsPush) {
        this.spInsertSmsPush = spInsertSmsPush;
    }
}