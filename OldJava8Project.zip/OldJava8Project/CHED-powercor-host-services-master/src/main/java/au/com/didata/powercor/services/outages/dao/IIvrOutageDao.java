package au.com.didata.powercor.services.outages.dao;

import au.com.didata.powercor.services.oms.dto.OutageByNMIResponseDTO;
import au.com.didata.powercor.services.oms.dto.OutageByPostcodeResponseDTO;

/**
 * Created with IntelliJ IDEA.
 * User: cang
 * Date: 11/05/12
 * Time: 11:52 AM
 * To change this template use File | Settings | File Templates.
 */


public interface IIvrOutageDao {
    public OutageByPostcodeResponseDTO getOutagesByPostcode(String thePostcode) throws Exception;
    public OutageByNMIResponseDTO getOutagesByNmi(String theNmi);

}
