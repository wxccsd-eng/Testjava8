package au.com.didata.powercor.services.playedmessages.dao.jdbc;

import au.com.didata.powercor.services.playedmessages.bean.PlayedMessagesRecord;
import au.com.didata.powercor.services.playedmessages.dao.IPlayedMessagesDao;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlInOutParameter;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * HR4.8
 */
public class PlayedMessagesJdbcDao implements IPlayedMessagesDao {

    static final Logger logger = Logger.getLogger(PlayedMessagesJdbcDao.class);

    private String spGetPlayedMessages;
    private String spInsertPlayedMessages;
    private JdbcTemplate jdbcTemplate;

    public void insertPlayedMessages(int routerCallKey,
                                     int routerCallKeyDay,
                                     String cli, String nmi, String streetName,
                                     String streetType, String suburb1,
                                     String suburb2, String suburb3,
                                     String suburb4, String suburb5, String postCode,
                                     Date etr, String message,
                                     String crewStatus, Boolean manualMessage, String restoredStatus,
                                     Boolean error ) {
        try {
            InsertPlayedMessageStoredProcedure proc = new InsertPlayedMessageStoredProcedure(
                    getJdbcTemplate().getDataSource(), spInsertPlayedMessages);

            Map results = proc.execute(
                    routerCallKey,
                    routerCallKeyDay,
                    cli, nmi, streetName,
                    streetType, suburb1,
                    suburb2, suburb3,
                    suburb4, suburb5,
                    etr, message,
                    crewStatus, manualMessage,
                    postCode, restoredStatus, error );

        } catch(DataAccessException ex) {
            logger.error(ex.getMessage());
            throw ex;
        }
    }

    class InsertPlayedMessageStoredProcedure extends StoredProcedure {
        private static final String ROUTERCALLKEY = "routerCallKey";
        private static final String ROUTERCALLKEYDAY = "routerCallKeyDay";
        private static final String DATETIME = "dateTime";
        private static final String CLI = "cli";
        private static final String NMI = "nmi";
        private static final String STREETNAME = "streetName";
        private static final String STREETTYPE = "streetType";
        private static final String SUBURB1 = "suburb1";
        private static final String SUBURB2 = "suburb2";
        private static final String SUBURB3 = "suburb3";
        private static final String SUBURB4 = "suburb4";
        private static final String SUBURB5 = "suburb5";
        private static final String ETR = "etr";
        private static final String MESSAGE = "message";
        private static final String CREWSTATUS = "crewStatus";
        private static final String MANUALMESSAGE = "manualMessage";
        private static final String POSTCODE = "postCode";
        private static final String RESTOREDSTATUS = "restoredStatus";
        private static final String ERROR = "error";
        
        public InsertPlayedMessageStoredProcedure(DataSource dataSource, String sprocName) {
            super(dataSource, sprocName);


            declareParameter(new SqlOutParameter("rc", Types.INTEGER ));

            declareParameter(new SqlParameter(ROUTERCALLKEY, Types.INTEGER));
            declareParameter(new SqlParameter(ROUTERCALLKEYDAY,Types.INTEGER));
//            declareParameter(new SqlParameter(DATETIME, Types.TIMESTAMP));

            declareParameter(new SqlParameter(CLI, Types.VARCHAR));
            declareParameter(new SqlParameter(NMI,Types.VARCHAR));
            declareParameter(new SqlParameter(STREETNAME,Types.VARCHAR));
            declareParameter(new SqlParameter(STREETTYPE,Types.VARCHAR));
            declareParameter(new SqlParameter(SUBURB1,Types.VARCHAR));
            declareParameter(new SqlParameter(SUBURB2,Types.VARCHAR));
            declareParameter(new SqlParameter(SUBURB3,Types.VARCHAR));
            declareParameter(new SqlParameter(SUBURB4,Types.VARCHAR));
            declareParameter(new SqlParameter(SUBURB5,Types.VARCHAR));
            declareParameter(new SqlParameter(ETR, Types.TIMESTAMP));
            declareParameter(new SqlParameter(MESSAGE, Types.VARCHAR));
            declareParameter(new SqlParameter(CREWSTATUS, Types.VARCHAR));
            declareParameter(new SqlParameter(MANUALMESSAGE, Types.BOOLEAN));
            declareParameter(new SqlParameter(POSTCODE, Types.VARCHAR));
            declareParameter(new SqlParameter(RESTOREDSTATUS, Types.VARCHAR));
            declareParameter(new SqlInOutParameter(ERROR, Types.BOOLEAN));


            setFunction(true); // need to set this if a function.

            compile();
         //   logger.info("Insert Message Procedure to be executed: "+ getSql());

        }

        public Map execute(Integer routerCallKey, Integer routerCallKeyDay,
                           String cli,
                           String nmi, String streetName, String streetType,
                           String suburb1, String suburb2,
                           String suburb3, String suburb4,
                           String suburb5, Date theETR,
                           String message, String crewStatus, Boolean isManualMessage,
                           String postCode, String restoredStatus, Boolean error) {

            Integer routerCallKeyInt = routerCallKey; // Integer.parseInt(routerCallKey);
            Integer routerCallKeyDayInt = routerCallKeyDay; // Integer.parseInt(routerCallKeyDay);

    //        logger.debug("insertPlayedMessages routerCallKey = " + routerCallKey + " routerCallKeyDay=" + " RCD=" + routerCallKeyDay + " cli=" + cli + " nmi=" + nmi + " streetName=" + streetName + " streetType=" + streetType + " suburb1=" + suburb1 + " suburb2=" + suburb2 +" suburb3=" + suburb3 +" suburb4=" + suburb4 +" suburb5=" + suburb5 + " postCode=" + postCode + " etr=" + theETR + " message=" + message + " crewStatus=" + crewStatus + " isManualMessage=" + isManualMessage + " restoredStatus=" + restoredStatus);
            Map inputs = new HashMap();

            inputs.put(ROUTERCALLKEY, routerCallKeyInt);
            inputs.put(ROUTERCALLKEYDAY, routerCallKeyDayInt);
//            inputs.put(DATETIME, theDateTime);
            inputs.put(CLI, cli);
            inputs.put(NMI, nmi);
            inputs.put(STREETNAME, streetName);
            inputs.put(STREETTYPE, streetType);
            inputs.put(SUBURB1, suburb1);
            inputs.put(SUBURB2, suburb2);
            inputs.put(SUBURB3, suburb3);
            inputs.put(SUBURB4, suburb4);
            inputs.put(SUBURB5, suburb5);
         //   inputs.put(ETR, new java.sql.Timestamp(theETR.getTime() )); // theETR);
            inputs.put(ETR, theETR);
            inputs.put(MESSAGE, message );
            inputs.put(CREWSTATUS, crewStatus);
            inputs.put(MANUALMESSAGE, isManualMessage );
            inputs.put(POSTCODE, postCode );
            inputs.put(RESTOREDSTATUS, restoredStatus);
            inputs.put(ERROR, error);

            return super.execute(inputs);
        }
    }


    public PlayedMessagesRecord getPlayedMessages(int routerCallKey,
                                                  int routerCallKeyDay,
                                                  Boolean isError ) {
        GetPlayedMessageStoredProcedure proc = new GetPlayedMessageStoredProcedure(
                getJdbcTemplate().getDataSource(), spGetPlayedMessages );

        PlayedMessagesJdbcDao.logger.debug("GetPlayedMessages: rck= " + routerCallKey + " rcd = " + routerCallKeyDay);
        
        Map results = proc.execute(
                routerCallKey,
                routerCallKeyDay,
                isError );

        List rs = (List)results.get( "rs" );
        if ( rs != null && rs.size() > 0) {
        	// PlayedMessagesRecord res = (PlayedMessagesRecord)rs.get( 0 );
            // Retrieve the last record inserted, not the first
        	PlayedMessagesRecord res = (PlayedMessagesRecord)rs.get(rs.size()-1);
        	if ( res != null ) {
                res.setRouterCallKey( routerCallKey );
                res.setRouterCallKeyDay( routerCallKeyDay );
            }
            return res;
        } else {
        	PlayedMessagesJdbcDao.logger.debug("no played messages for rck = " + routerCallKey + " rcd = " + routerCallKeyDay);
        }
        return null;
    }

    class GetPlayedMessageStoredProcedure extends StoredProcedure {

    	
        private static final String ROUTERCALLKEY = "routerCallKey";
        private static final String ROUTERCALLKEYDAY = "routerCallKeyDay";
        private static final String DATETIME = "date_Time";
        private static final String CLI = "cli";
        private static final String NMI = "nmi";
        private static final String STREETNAME = "street_Name";
        private static final String STREETTYPE = "street_Type";
        private static final String SUBURB1 = "suburb_1";
        private static final String SUBURB2 = "suburb_2";
        private static final String SUBURB3 = "suburb_3";
        private static final String SUBURB4 = "suburb_4";
        private static final String SUBURB5 = "suburb_5";
        private static final String ETR = "etr";
        private static final String MESSAGE = "outage_message";
        private static final String CREWSTATUS = "crew_Status";
        private static final String MANUALMESSAGE = "manual_Message";
        private static final String POSTCODE = "postcode";
        private static final String RESTOREDSTATUS = "restoredStatus";
        private static final String ERROR = "error";

        public GetPlayedMessageStoredProcedure(DataSource dataSource, String sprocName) {
            super(dataSource, sprocName);

            setResultSetType(ResultSet.TYPE_SCROLL_INSENSITIVE );

            declareParameter(new SqlOutParameter("rc", Types.INTEGER ));

            declareParameter(new SqlReturnResultSet("rs", new RecordMapper()));

            declareParameter(new SqlParameter(ROUTERCALLKEY, Types.INTEGER));
            declareParameter(new SqlParameter(ROUTERCALLKEYDAY,Types.INTEGER));
            declareParameter(new SqlParameter(ERROR,Types.BOOLEAN));

            setFunction(true); // need to set this if a function.

            compile();
      //      logger.info("Procedure to be executed: "+getSql());
        }

        public Map execute(Integer  routerCallKey, Integer routerCallKeyDay,
                           Boolean error) {

            int routerCallKeyInt = routerCallKey; // Integer.parseInt(routerCallKey);
            int routerCallKeyDayInt = routerCallKeyDay; // Integer.parseInt(routerCallKeyDay);

            PlayedMessagesJdbcDao.logger.debug("GetPlayedMessages execute: rck= " + routerCallKey + " rcd = " + routerCallKeyDay);
            Map inputs = new HashMap();

           // declareParameter(new SqlOutParameter("rc", Types.VARCHAR ));

            inputs.put(ROUTERCALLKEY, routerCallKeyInt);
            inputs.put(ROUTERCALLKEYDAY, routerCallKeyDayInt);
            inputs.put(ERROR, error );

            return super.execute(inputs);
        }
    }

    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public void setSpGetPlayedMessages(String spGetPlayedMessages) {
        this.spGetPlayedMessages = spGetPlayedMessages;
    }

    public void setSpInsertPlayedMessages(String spInsertPlayedMessages) {
        this.spInsertPlayedMessages = spInsertPlayedMessages;
    }

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    protected static final class RecordMapper implements RowMapper {
        public Object mapRow(java.sql.ResultSet rs, int rowNum) throws SQLException {

            PlayedMessagesRecord record = new PlayedMessagesRecord();

            ResultSetMetaData rsMetaData = rs.getMetaData();

            int columnCount = rsMetaData.getColumnCount();
            for (int i=1; i<=columnCount; i++) {
            	PlayedMessagesJdbcDao.logger.debug("PlayedMessages field:" + rsMetaData.getColumnName(i) + "=" + rs.getString(i) );

            }
            record.setCallDate( rs.getTimestamp( GetPlayedMessageStoredProcedure.DATETIME ));
            record.setCli( rs.getString( GetPlayedMessageStoredProcedure.CLI ));
            record.setNmi( rs.getString( GetPlayedMessageStoredProcedure.NMI ));
            record.setStreetName( rs.getString( GetPlayedMessageStoredProcedure.STREETNAME ));
            record.setStreetType( rs.getString( GetPlayedMessageStoredProcedure.STREETTYPE ));
            record.setSuburb1( rs.getString( GetPlayedMessageStoredProcedure.SUBURB1 ));
            record.setSuburb2( rs.getString( GetPlayedMessageStoredProcedure.SUBURB2 ));
            record.setSuburb3( rs.getString( GetPlayedMessageStoredProcedure.SUBURB3 ));
            record.setSuburb4( rs.getString( GetPlayedMessageStoredProcedure.SUBURB4 ));
            record.setSuburb5( rs.getString( GetPlayedMessageStoredProcedure.SUBURB5 ));
            record.setEtr( rs.getTimestamp( GetPlayedMessageStoredProcedure.ETR ));
            record.setMessage( rs.getString( GetPlayedMessageStoredProcedure.MESSAGE ));
            record.setCrewStatus( rs.getString( GetPlayedMessageStoredProcedure.CREWSTATUS ));
            record.setManualMessage( rs.getBoolean( GetPlayedMessageStoredProcedure.MANUALMESSAGE ));
            record.setPostCode( rs.getString( GetPlayedMessageStoredProcedure.POSTCODE ));
            record.setRestoredStatus(rs.getString(GetPlayedMessageStoredProcedure.RESTOREDSTATUS));
            return record;
        }
    }
}
