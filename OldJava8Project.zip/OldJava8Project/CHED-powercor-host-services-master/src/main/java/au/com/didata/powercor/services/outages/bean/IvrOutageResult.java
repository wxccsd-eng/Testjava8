package au.com.didata.powercor.services.outages.bean;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: cang
 * Date: 11/05/12
 * Time: 11:45 AM
 * To change this template use File | Settings | File Templates.
 */
public class IvrOutageResult {
    private String suburb1;
    private String suburb2;
    private String suburb3;
    private String suburb4;
    private String suburb5;

    private Date etr;
    private String message;
    private String crewStatus;

    public IvrOutageResult(String suburb1, Date etr, String message, String crewStatus) {
        this.suburb1 = suburb1;
        this.etr = etr;
        this.message = message;
        this.crewStatus = crewStatus;
    }

    public String getSuburb1() {
        return suburb1;
    }

    public void setSuburb1(String suburb1) {
        this.suburb1 = suburb1;
    }

    public String getSuburb2() {
        return suburb2;
    }

    public void setSuburb2(String suburb2) {
        this.suburb2 = suburb2;
    }

    public String getSuburb3() {
        return suburb3;
    }

    public void setSuburb3(String suburb3) {
        this.suburb3 = suburb3;
    }

    public String getSuburb4() {
        return suburb4;
    }

    public void setSuburb4(String suburb4) {
        this.suburb4 = suburb4;
    }

    public String getSuburb5() {
        return suburb5;
    }

    public void setSuburb5(String suburb5) {
        this.suburb5 = suburb5;
    }

    public Date getEtr() {
        return etr;
    }

    public void setEtr(Date etr) {
        this.etr = etr;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCrewStatus() {
        return crewStatus;
    }

    public void setCrewStatus(String crewStatus) {
        this.crewStatus = crewStatus;
    }

    @Override
    public String toString() {
        return "IvrOutageResult{" +
                "suburb1='" + suburb1 + '\'' +
                ", suburb2='" + suburb2 + '\'' +
                ", suburb3='" + suburb3 + '\'' +
                ", suburb4='" + suburb4 + '\'' +
                ", suburb5='" + suburb5 + '\'' +
                ", etr=" + etr +
                ", message='" + message + '\'' +
                ", crewStatus='" + crewStatus + '\'' +
                '}';
    }
}

