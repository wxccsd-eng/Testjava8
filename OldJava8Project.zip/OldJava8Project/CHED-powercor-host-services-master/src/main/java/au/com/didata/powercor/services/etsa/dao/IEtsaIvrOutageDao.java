/**
 * Dimension Data Holdings plc. Confidential
 * 
 * Source Materials
 * 
 * RTA IVRCIMS Phase 1 - AU003203
 * 
 * Copyright (C) 2010 Dimension Data Holdings plc.
 * 
 * This library is confidential. No part of this library may be reproduced,
 * used or distributed for any purpose, without the prior written consent of Dimension 
 * Data Australia Pty Limited. This library is confidential and use, reproduction or 
 * distribution of this library or any part of it for any purpose, other than for 
 * selection of a supplier for the goods and/or services tendered, is STRICTLY PROHIBITED.
 *
 * $HeadURL$
 * $Id$ 
 */
package au.com.didata.powercor.services.etsa.dao;

import au.com.didata.powercor.services.etsapos.dto.EtsaOutageByNmiResponseDTO;
import au.com.didata.powercor.services.etsapos.dto.EtsaOutageByPostcodeResponseDTO;
		
public interface IEtsaIvrOutageDao {
	
	public EtsaOutageByNmiResponseDTO getOutagesByNmi(String nmi);
	public EtsaOutageByPostcodeResponseDTO getOutagesByPostcode(String pcode) throws Exception;

}
