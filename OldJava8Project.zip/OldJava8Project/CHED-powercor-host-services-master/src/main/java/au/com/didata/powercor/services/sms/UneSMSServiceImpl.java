package au.com.didata.powercor.services.sms;

import java.util.Date;

import org.apache.log4j.Logger;

import au.com.didata.powercor.services.exceptions.NoConnectionException;
import au.com.didata.powercor.services.exceptions.NoResponseException;
import au.com.didata.powercor.services.exceptions.PlatformErrorException;
import au.com.didata.powercor.services.exceptions.ServiceImplException;
import au.com.didata.powercor.services.sms.ISMSService;
import au.com.didata.powercor.services.sms.dao.ISmsPushDao;
import au.com.didata.powercor.services.sms.dto.SMSPushResponseDTO;

public class UneSMSServiceImpl implements ISMSService {

	static final Logger logger = Logger.getLogger(UneSMSServiceImpl.class);
	static final String VERSION = "0.0";
	
	//Actions
	public static final String ACTION_SMS_PUSH = "smsUnePush";

	// Request and response parameters
	private static final String PARAMETER_VERSION = "version";
	
	public static final int SUCCESS_CODE = 0;
	public static final int ERROR_CODE = -1;
	
	private ISmsPushDao uneSmsDao;

	private boolean isEmpty(String s) {
		
		if (s == null || s.length() == 0)
			return true;
		else
			return false;
	}


	public SMSPushResponseDTO smsPush(String nmi, String mobile) throws NoConnectionException, NoResponseException, PlatformErrorException, ServiceImplException {
		
		
		if (logger.isInfoEnabled()) logger.info(String.format("SMS: smsPush (une): version= %s, nmi=%s, mobile=%s",VERSION, nmi, mobile ));
		
		// TODO: This is where to call relevant services to get the host data
		

		SMSPushResponseDTO responseDTO = new SMSPushResponseDTO();

		try {
			Date now = new Date();
			Integer response = uneSmsDao.insertSmsPush(nmi, mobile, now);
			if (logger.isDebugEnabled()) logger.debug(String.format("SMS: insertSmsPush (une, response): %s",response));
			// Set default error code 0
			responseDTO.setErrorCode(SUCCESS_CODE);
		} catch (Exception e) {
			ServiceImplException se = new ServiceImplException("Unexpected error during execution of smsPush() (UNE) request", e);
			logger.error("Response exception", e);
			throw se;	
		}
		
		logger.debug(String.format("smsPush (UNE) completed for nmi: %s and mobile: %s",mobile,nmi ));	
		return responseDTO;
	}

	public void setUneSmsDao(ISmsPushDao smsDao) {
		this.uneSmsDao = smsDao;
	}
}
