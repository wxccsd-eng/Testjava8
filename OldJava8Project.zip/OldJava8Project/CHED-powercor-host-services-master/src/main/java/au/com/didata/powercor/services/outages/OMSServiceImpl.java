package au.com.didata.powercor.services.outages;

import au.com.didata.powercor.services.oms.IOMSService;
import au.com.didata.powercor.services.oms.dto.OutageByNMIResponseDTO;
import au.com.didata.powercor.services.oms.dto.OutageByPostcodeResponseDTO;
import au.com.didata.powercor.services.outages.dao.IIvrOutageDao;

import org.apache.log4j.Logger;

import au.com.didata.powercor.services.exceptions.NoConnectionException;
import au.com.didata.powercor.services.exceptions.NoResponseException;
import au.com.didata.powercor.services.exceptions.PlatformErrorException;
import au.com.didata.powercor.services.exceptions.ServiceImplException;

public class OMSServiceImpl implements IOMSService {

	static final Logger logger = Logger.getLogger(OMSServiceImpl.class);
	static final String VERSION = "0.0";
	
	public static final int SUCCESS_CODE = 0;
	public static final int ERROR_CODE = -1;
	
	//Actions
	public static final String ACTION_GET_OUTAGES_BY_NMI = "getOutagesByNMI";
	public static final String ACTION_GET_OUTAGES_BY_POSTCODE = "getOutagesByPostcode";
	
	// Request and response parameters
	private static final String PARAMETER_VERSION = "version";

    private IIvrOutageDao ivrOutageDao;
	

	private boolean isEmpty(String s) {
		
		if (s == null || s.length() == 0)
			return true;
		else
			return false;
	}

	
	/**
	 * Helper method used to format a string where sensitive data can be blocked if required
	 * 
	 * @param  query
	 * @throws IllegalArgumentException		if input argument is null
	 * @return String
	 * @throws 
	 */
	protected String logQueryString(String query) {
	
		return query;			
	}
	
	public static void main(String[] args) {
		
			
	}

  //  @Override
	public OutageByNMIResponseDTO getOutagesByNMI(String NMI) throws NoConnectionException, NoResponseException, PlatformErrorException, ServiceImplException {

		if (logger.isInfoEnabled()) {
			
			logger.info("CISOV: getOutagesByNMI: " + "version=" + VERSION );
		}
		
		// TODO: This is where to call relevant services to get the host data

		OutageByNMIResponseDTO outageResponseDTO = new OutageByNMIResponseDTO();

		
		logger.debug("Requesting Outage for NMI: " + NMI);	
		
		try{
			 outageResponseDTO = ivrOutageDao.getOutagesByNmi(NMI);
			 if (outageResponseDTO == null) {
				// No record returned for NMI
				throw new NoResponseException(ERROR_CODE, "No Outage for NMI: " + NMI);
			 }
			 outageResponseDTO.setErrorCode(SUCCESS_CODE);
		} catch (Exception e) {
			ServiceImplException se = new ServiceImplException("Unexpected error during execution of getOutagesByNMI() request", e);
			logger.error("Response exception", e);
			throw se;	
		}
	
		return outageResponseDTO;

	}

	public OutageByPostcodeResponseDTO getOutagesByPostcode(String postcode)throws NoConnectionException, NoResponseException, PlatformErrorException, ServiceImplException {

		if (logger.isInfoEnabled()) {
			
			logger.info("CISOV: getOutagesByPostcode: " + "version=" + VERSION );
		}
		
		// TODO: This is where to call relevant services to get the host data

		OutageByPostcodeResponseDTO outageResponseDTO = new OutageByPostcodeResponseDTO();
	
		
		logger.debug("Requesting Outage for Postcode: " + postcode);	
		
		try{
			 outageResponseDTO = ivrOutageDao.getOutagesByPostcode(postcode);
			 if (outageResponseDTO == null) {
				// No record returned for NMI
				throw new NoResponseException(ERROR_CODE, "No Outage for Postcode: " + postcode);
			 }
			 outageResponseDTO.setErrorCode(SUCCESS_CODE);
		} catch (Exception e) {
			ServiceImplException se = new ServiceImplException("Unexpected error during execution of getOutagesForPostcode() request", e);
			logger.error("Response exception", e);
			throw se;	
		}

		return outageResponseDTO;
	}

    public void setIvrOutageDao(IIvrOutageDao ivrOutageDao) {
        this.ivrOutageDao = ivrOutageDao;
    }
}
