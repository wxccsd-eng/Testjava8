package au.com.didata.powercor.services.outages.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.logging.Logger;

/**
 * Created with IntelliJ IDEA.
 * User: cang
 * Date: 11/05/12
 * Time: 11:44 AM
 * To change this template use File | Settings | File Templates.
 */
public class IvrOutageInfoRecord implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private static final Logger logger = Logger.getLogger(IvrOutageInfoRecord.class.getName());

    private Integer orderId;
    private Integer localityId;
    private String localityName;
    private String postcode;
    private String message;
    private String crewStatus;
    private Integer customersAffected;
    private Integer planned;
    private Timestamp etr;
    private String faultMemo;
    private Integer poweronUpdate;

    @Override
    public String toString() {
        return "IvrOutageInfoRecord{" +
                "orderId=" + orderId +
                ", localityId=" + localityId +
                ", localityName='" + localityName + '\'' +
                ", postcode='" + postcode + '\'' +
                ", message='" + message + '\'' +
                ", crewStatus='" + crewStatus + '\'' +
                ", customersAffected=" + customersAffected +
                ", planned=" + planned +
                ", etr=" + etr +
                ", faultMemo='" + faultMemo + '\'' +
                ", poweronUpdate=" + poweronUpdate +
                '}';
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getLocalityId() {
        return localityId;
    }

    public void setLocalityId(Integer localityId) {
        this.localityId = localityId;
    }

    public String getLocalityName() {
        return localityName;
    }

    public void setLocalityName(String localityName) {
        this.localityName = localityName;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCrewStatus() {
        return crewStatus;
    }

    public void setCrewStatus(String crewStatus) {
        this.crewStatus = crewStatus;
    }

    public Integer getCustomersAffected() {
        return customersAffected;
    }

    public void setCustomersAffected(Integer customersAffected) {
        this.customersAffected = customersAffected;
    }

    public Integer getPlanned() {
        return planned;
    }

    public void setPlanned(Integer planned) {
        this.planned = planned;
    }

    public Timestamp getEtr() {
        return etr;
    }

    public void setEtr(Timestamp etr) {
        this.etr = etr;
    }

    public String getFaultMemo() {
        return faultMemo;
    }

    public void setFaultMemo(String faultMemo) {
        this.faultMemo = faultMemo;
    }

    public Integer getPoweronUpdate() {
        return poweronUpdate;
    }

    public void setPoweronUpdate(Integer poweronUpdate) {
        this.poweronUpdate = poweronUpdate;
    }

}