package au.com.didata.powercor.services.repeatcaller;

import org.apache.log4j.Logger;

import au.com.didata.powercor.services.exceptions.NoConnectionException;
import au.com.didata.powercor.services.exceptions.NoResponseException;
import au.com.didata.powercor.services.exceptions.PlatformErrorException;
import au.com.didata.powercor.services.exceptions.ServiceImplException;
import au.com.didata.powercor.services.repeatcaller.dao.RepeatCallerDao;
import au.com.didata.powercor.services.repeatcaller.dto.InputCallerResponseDTO;
import au.com.didata.powercor.services.repeatcaller.dto.RepeatCallerResponseDTO;

public class RepeatCallerServiceImpl implements IRepeatCallerService {

	static final Logger logger = Logger.getLogger(RepeatCallerServiceImpl.class);
	static final String VERSION = "0.0";
	
	// Actions
	public static final String ACTION_GET_REPEAT_CALLERS = "getRepeatCallers";
	public static final String ACTION_INPUT_REPEAT_CALLERS = "inputRepeatCallers";
	public static final int SUCCESS_CODE = 0;
	public static final int ERROR_CODE = -1;

	// Request and response parameters
	private static final String PARAMETER_VERSION = "version";
	
	private RepeatCallerDao repeatCallerDao;
	

	private boolean isEmpty(String s) {
		
		if (s == null || s.length() == 0)
			return true;
		else
			return false;
	}

	
	
	/**
	 * Helper method used to format a string where sensitive data can be blocked if required
	 * 
	 * @param  query
	 * @throws IllegalArgumentException		if input argument is null
	 * @return String
	 * @throws 
	 */
	protected String logQueryString(String query) {
	
		return query;			
	}
	
	public static void main(String[] args) {
		
			
	}

	public RepeatCallerResponseDTO getRepeatCallers(String routerCallKey,
			String routerCallKeyDay, String cli, String dnis, String callType,
			String nmi, String distributionBusiness) throws NoConnectionException, NoResponseException, PlatformErrorException, ServiceImplException {

		if (logger.isInfoEnabled()) {
				
				logger.info("RepeatCaller: getRepeatCallers: " + "version=" + VERSION );
			}
			
		// TODO: This is where to call relevant services to get the host data
			
		int repeatCallerCount = 0;
		RepeatCallerResponseDTO response = null;
		
		logger.info("Requesting RepeatCallerCheck for cli:" + cli + " and nmi " + nmi);	

		if (!cli.matches("[0-9]*")) {   
			logger.debug("cli alphanumeric - setting to blank string");  
			cli = "";
		}  
		if (!nmi.matches("[0-9]*")) {  
			logger.debug("nmi alphanumeric - setting to blank string");  
			nmi = "";
		}  
		
		try {
            Integer repeatCallers  = 0;
			repeatCallerCount = repeatCallerDao.getRepeatCallers(routerCallKey,
                    routerCallKeyDay, cli, dnis, callType, nmi, distributionBusiness,
                    repeatCallers );
			logger.debug("repeatCallerCount = " + repeatCallerCount);
		} catch (NumberFormatException nfe) {
			PlatformErrorException pe = new PlatformErrorException(ERROR_CODE, nfe.getMessage());
			logger.error("NumberFormatException", pe);
			throw pe;
		} catch (Exception e) {
			ServiceImplException se = new ServiceImplException("Unexpected error during execution of getRepeatCaller() request", e);
			logger.error("Response exception", e);
			throw se;	
		}
			
		if (repeatCallerCount != 0) {
				
			logger.info("repeatCallerCount = " + repeatCallerCount);
				
			response = new RepeatCallerResponseDTO();
					
			response.setErrorCode(SUCCESS_CODE);
			response.setRepeatCalls(Integer.toString(repeatCallerCount));
		} else {
			// No record returned for CLI
			throw new NoResponseException(ERROR_CODE, "No RepeatCaller for CLI: " + cli);
		}

		return response;
	}



	public InputCallerResponseDTO inputRepeatCallers(String routerCallKey,
			String routerCallKeyDay, String cli, String dnis, String callType,
			String nmi, String distributionBusiness) throws NoConnectionException, NoResponseException, PlatformErrorException, ServiceImplException {

		if (logger.isInfoEnabled()) {
			
			logger.info("RepeatCaller: inputRepeatCallers: " + "version=" + VERSION );
		}
		
		// TODO: This is where to call relevant services to get the host data
		InputCallerResponseDTO response = new InputCallerResponseDTO();
		
		logger.debug("Inserting caller details: routerCallKey=" + routerCallKey + " routerCallKeyDay=" + routerCallKeyDay + " cli=" + cli + " dnis= " + dnis + " callType=" + callType + " nmi=" + nmi + " distributionBusines= " + distributionBusiness);	

		if (!cli.matches("[0-9]*")) {   
			logger.debug("cli alphanumeric - setting to blank string");  
			cli = "";
		}  
		if (!nmi.matches("[0-9]*")) {  
			logger.debug("nmi alphanumeric - setting to blank string");  
			nmi = "";
		}  
		
		try {
			repeatCallerDao.insertRepeatCaller(Integer.parseInt(routerCallKey), Integer.parseInt(routerCallKeyDay), cli, dnis, callType, nmi, distributionBusiness);
		} catch (NumberFormatException nfe) {
			PlatformErrorException pe = new PlatformErrorException(ERROR_CODE, nfe.getMessage());
			logger.error("NumberFormatException", pe);
			throw pe;
		} catch (Exception e) {
			ServiceImplException se = new ServiceImplException("Unexpected error during execution of getRepeatCaller() request", e);
			logger.error("Response exception", e);
			throw se;	
		}
		
		logger.info("Returning RepeatCallerCheck completed");			
		response.setErrorCode(SUCCESS_CODE);
		
		return response;
	}

	public void setRepeatCallerDao(RepeatCallerDao repeatCallerDao) {
		this.repeatCallerDao = repeatCallerDao;
	}
	
}
