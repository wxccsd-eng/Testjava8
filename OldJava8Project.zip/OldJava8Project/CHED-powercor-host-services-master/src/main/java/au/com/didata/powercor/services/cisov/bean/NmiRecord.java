/**
 * Dimension Data Holdings plc. Confidential
 * 
 * Source Materials
 * 
 * RTA IVRCIMS Phase 1 - AU003203
 * 
 * Copyright (C) 2010 Dimension Data Holdings plc.
 * 
 * This library is confidential. No part of this library may be reproduced,
 * used or distributed for any purpose, without the prior written consent of Dimension 
 * Data Australia Pty Limited. This library is confidential and use, reproduction or 
 * distribution of this library or any part of it for any purpose, other than for 
 * selection of a supplier for the goods and/or services tendered, is STRICTLY PROHIBITED.
 *
 * $HeadURL$
 * $Id$ 
 */
package au.com.didata.powercor.services.cisov.bean;

import java.io.Serializable;

import org.apache.log4j.Logger;

public class NmiRecord implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger logger = Logger.getLogger("NMIRecord.class");
	
	String telephoneNo;
	String nmi;
	String suburb;
	String postCode;
	String street;
	String unit;
	String floor;
	String lot;
	String bldgNo;
	String nmPreferred;
	String state;

	public String getTelephoneNo() {
		return telephoneNo;
	}

	public void setTelephoneNo(String telephoneNo) {
		this.telephoneNo = telephoneNo;
	}

	public String getNmi() {
		return nmi;
	}

	public void setNmi(String nmi) {
		this.nmi = nmi;
	}

	public String getSuburb() {
		return suburb;
	}

	public void setSuburb(String suburb) {
		this.suburb = suburb;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public String getLot() {
		return lot;
	}

	public void setLot(String lot) {
		this.lot = lot;
	}

	public String getBldgNo() {
		return bldgNo;
	}

	public void setBldgNo(String bldgNo) {
		this.bldgNo = bldgNo;
	}

	public String getNmPreferred() {
		return nmPreferred;
	}

	public void setNmPreferred(String nmPreferred) {
		this.nmPreferred = nmPreferred;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String toString() {
		return new StringBuffer("NMIRecord: ").
					append(" TelephoneNo=").append(getTelephoneNo()).
					append(" NMI=").append(getNmi()).
					append(" Suburb=").append(getSuburb()).
					append(" PostCode=").append(getPostCode()).
					append(" Street=").append(getStreet()).
					append(" Unit=").append(getUnit()).
					append(" Floor=").append(getFloor()).
					append(" Lot=").append(getLot()).
					append(" BuildingNo=").append(getBldgNo()).
					append(" NMPreferred=").append(getNmPreferred()).
					toString();
		
	}
}
