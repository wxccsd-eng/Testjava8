package au.com.didata.powercor.services.outages;

import org.apache.log4j.Logger;

import au.com.didata.powercor.services.exceptions.NoConnectionException;
import au.com.didata.powercor.services.exceptions.NoResponseException;
import au.com.didata.powercor.services.exceptions.PlatformErrorException;
import au.com.didata.powercor.services.exceptions.ServiceImplException;
import au.com.didata.powercor.services.manualmessage.IManualMessageService;
import au.com.didata.powercor.services.manualmessage.dto.RetrieveMessagePlayedResponseDTO;
import au.com.didata.powercor.services.oms.dto.OutageByPostcodeResponseDTO;
import au.com.didata.powercor.services.outages.dao.IIvrOutageDao;

public class UneManualMessagesServiceImpl implements IManualMessageService {

	static final Logger logger = Logger.getLogger(UneManualMessagesServiceImpl.class);
	static final String VERSION = "0.0";
	
	//Actions
	public static final String ACTION_GET_MANUAL_MESSAGE_OVERRIDE = "getManualMessageOverride";
	public static final String ACTION_RETRIEVE_MESSAGE_PLAYED = "retrieveMessagePlayed";
	
	public static final int SUCCESS_CODE = 0;
	public static final int ERROR_CODE = -1;
	
	// Request and response parameters
	private static final String PARAMETER_VERSION = "version";
	
	private IIvrOutageDao uneIvrOutageDao;
	

	private boolean isEmpty(String s) {
		
		if (s == null || s.length() == 0)
			return true;
		else
			return false;
	}

	
	/**
	 * Helper method used to format a string where sensitive data can be blocked if required
	 * 
	 * @param  query
	 * @throws IllegalArgumentException		if input argument is null
	 * @return String
	 * @throws 
	 */
	protected String logQueryString(String query) {
	
		return query;			
	}
	
	public static void main(String[] args) {
		
			
	}


	public OutageByPostcodeResponseDTO getManualMessageOverride(String postcode) throws NoConnectionException, NoResponseException, PlatformErrorException, ServiceImplException {
		if (logger.isInfoEnabled()) logger.info(String.format("UneManualMessages: getManualMessageOverride : postcode %s, version=%s", postcode, VERSION ));
		
		
		// TODO: This is where to call relevant services to get the host data
		
		OutageByPostcodeResponseDTO response = null;
		
		try {
			response = uneIvrOutageDao.getOutagesByPostcode(postcode);
		
		} catch (NumberFormatException nfe) {
			PlatformErrorException pe = new PlatformErrorException(ERROR_CODE, nfe.getMessage());
			logger.error("UneManualMessages: getManualMessageOverride : NumberFormatException", pe);
			throw pe;
		} catch (Exception e) {
			ServiceImplException se = new ServiceImplException("Unexpected error during execution of getManualMessageOverride() request", e);
			logger.error("UneManualMessages: getManualMessageOverride : Response exception", e);
			throw se;	
		}
			
		if (response == null) {
				
			// No record returned for CLI
			throw new NoResponseException(ERROR_CODE, "UneManualMessages: getManualMessageOverride : No ManualMessage for postcode: " + postcode);
		}
	
		return response;

	}


	public RetrieveMessagePlayedResponseDTO retrieveMessagePlayed(
			String routerCallKey, String routerCallKeyDay)
					throws NoConnectionException, NoResponseException, PlatformErrorException, ServiceImplException {
		
		if (logger.isInfoEnabled()) logger.info(String.format("UneManualMessages: retrieveMessagePlayed: version=%s", VERSION ));

		// TODO: This is where to call relevant services to get the host data		
		RetrieveMessagePlayedResponseDTO responseDTO = new RetrieveMessagePlayedResponseDTO();
	
		// Set default error code 0
		responseDTO.setErrorCode(0);
		
		if (logger.isDebugEnabled()) logger.debug(String.format("UneManualMessages: retrieveMessagePlayed: returning=%s", responseDTO ));		
		return responseDTO;
	}

	public void setUneIvrOutageDao(IIvrOutageDao ivrOutageDao) {
		this.uneIvrOutageDao = ivrOutageDao;
	}
	
}
