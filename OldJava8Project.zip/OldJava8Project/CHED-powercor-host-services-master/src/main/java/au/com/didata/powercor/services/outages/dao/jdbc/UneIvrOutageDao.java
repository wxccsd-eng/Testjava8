package au.com.didata.powercor.services.outages.dao.jdbc;

import au.com.didata.powercor.services.oms.dto.OutageByNMIResponseDTO;
import au.com.didata.powercor.services.oms.dto.OutageByPostcodeResponseDTO;
import au.com.didata.powercor.services.outages.bean.IvrOutageInfoRecord;
import au.com.didata.powercor.services.outages.dao.IIvrOutageDao;
import au.com.didata.powercor.services.outages.dao.jdbc.IvrOutageDao.RecordMapper;
import oracle.jdbc.internal.OracleTypes;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlInOutParameter;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: cang
 * Date: 11/05/12
 * Time: 11:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class UneIvrOutageDao implements IIvrOutageDao {

    private static final Logger logger = Logger.getLogger(UneIvrOutageDao.class);

    private String outagesByPostcodeStoredProcName;
    private String outagesByPostcodeStoredProcDriverType = "oracle";
    private String outagesByNmiStoredProcName;
    private JdbcTemplate jdbcTemplate;
    private static final String ETR_UNKNOWN = null;

    class HR44StoredProcedure extends StoredProcedure {
        private static final String CLI = "cli";

        public HR44StoredProcedure(DataSource dataSource, String sprocName, String sprocDriverType) {
            super(dataSource, sprocName);

//            declareParameter(new SqlOutParameter("rs", OracleTypes.CURSOR, new RecordMapper()));
            setResultSetType(ResultSet.TYPE_SCROLL_INSENSITIVE );

            if ("oracle".equals(sprocDriverType)) {
            	setFunction(true); // need to set this if a function.
            	declareParameter(new SqlOutParameter("rs", OracleTypes.CURSOR, new RecordMapper()));
            	declareParameter(new SqlParameter( "PCODE", OracleTypes.CHAR));
            } else {
            	declareParameter(new SqlReturnResultSet("rs", new RecordMapper()));
                declareParameter(new SqlParameter( "PCODE", Types.CHAR));
            }

            // http://stackoverflow.com/questions/862694/how-to-call-oracle-function-or-stored-procedure-using-spring-persistence-framewo
//            setFunction(true); // need to set this if a function.
            compile();
        }

        public Map execute(String pcode ) {
            Map inputs = new HashMap();
            inputs.put( "PCODE", pcode);
            return super.execute(inputs);
        }
    }

    class HR43StoredProcedure extends StoredProcedure {
        private static final String CLI = "cli";

        public HR43StoredProcedure(DataSource dataSource, String sprocName) {
            super(dataSource, sprocName);

            declareParameter(new SqlOutParameter("rowCount", OracleTypes.INTEGER));

            declareParameter(new SqlInOutParameter( "NMI", OracleTypes.CHAR));
            declareParameter(new SqlInOutParameter( "STREET_NAME", OracleTypes.CHAR));
            declareParameter(new SqlInOutParameter( "STREET_TYPE", OracleTypes.CHAR));
            declareParameter(new SqlInOutParameter( "LOCALITY", OracleTypes.CHAR));
            declareParameter(new SqlInOutParameter( "ETR", OracleTypes.CHAR));
            declareParameter(new SqlInOutParameter( "ETRUNKNOWN", OracleTypes.CHAR));
            declareParameter(new SqlInOutParameter( "MESSAGE", OracleTypes.CHAR));
            declareParameter(new SqlInOutParameter( "ORDER_ID", OracleTypes.CHAR));
            declareParameter(new SqlInOutParameter( "CREW_STATUS", OracleTypes.CHAR));
            // http://stackoverflow.com/questions/862694/how-to-call-oracle-function-or-stored-procedure-using-spring-persistence-framewo
            setFunction(true); // need to set this if a function.
            compile();
        }

        public Map execute(String nmi ) {
            Map inputs = new HashMap();
            String streetName = new String();
            inputs.put( "NMI", nmi);
            // just made all assign to streetname, as not used.
            inputs.put("STREET_NAME", streetName);
            inputs.put("STREET_TYPE", streetName);
            inputs.put("LOCALITY", streetName);
            inputs.put("ETR", streetName);
            inputs.put("ETRUNKNOWN", streetName);
            inputs.put("MESSAGE", streetName);
            inputs.put("ORDER_ID", streetName);
            inputs.put("CREW_STATUS", streetName);
            return super.execute(inputs);
        }
    }
    
    /**
     * Helper method to HostRequest4.4 to return only unique suburbs
     */
    private List<IvrOutageInfoRecord> getUniqueRecord(List<IvrOutageInfoRecord> recordIvrs  ) {
    	   
    	List<IvrOutageInfoRecord> uniqueRecordList = null;
    	 
    	if (recordIvrs != null ) {
    	    
    		List<String> localityNameSet = new ArrayList<String>();
    	    String localityName = null;
    	   
    	    uniqueRecordList = new ArrayList<IvrOutageInfoRecord>();
    	    for ( IvrOutageInfoRecord row : recordIvrs ) {
    	    	localityName = row.getLocalityName();
    	        if ( !localityNameSet.contains( localityName)) {
    	        	localityNameSet.add(localityName);
    	            uniqueRecordList.add(row);
    	         }
    	    }
    	}
    	return uniqueRecordList;
   }
    /**
     * This is HostRequest4.4
     */
    public OutageByPostcodeResponseDTO getOutagesByPostcode(String pcode) throws Exception {

        List<IvrOutageInfoRecord> recordIvrs = null;

        try {
        	if(logger.isInfoEnabled()) logger.info(String.format("UNE: entering getOutagesByPostcode: postcode = [%s], StoredProc=[%s]", pcode,outagesByPostcodeStoredProcName));
        	
            HR44StoredProcedure proc = new HR44StoredProcedure(
                    getJdbcTemplate().getDataSource(), outagesByPostcodeStoredProcName, outagesByPostcodeStoredProcDriverType);

            Map results = proc.execute( pcode );
            
            recordIvrs = getUniqueRecord( (List)results.get("rs") );
            

            if (recordIvrs == null || recordIvrs.isEmpty()) {
            	if(logger.isInfoEnabled()) logger.info(String.format("UNE: exiting getOutagesByPostcode: No results returned: postcode = %s", pcode));
                return null;
            }

            OutageByPostcodeResponseDTO res = null;
            int count = 0;
            for ( IvrOutageInfoRecord row : recordIvrs ) {
            	if (logger.isDebugEnabled()) logger.debug("UNE: getOutagesByPostcode: Outage row = " + row);
            	
                if ( res == null ) {
                    res = new OutageByPostcodeResponseDTO();
                    res.setSuburb1( row.getLocalityName() );
                    if (row.getEtr() != null) {
                    	res.setEtr(row.getEtr().toString()); // TODO this Date format might be a problem
                    } else {
                    	if (logger.isDebugEnabled()) logger.debug("Etr is null - setting to null value");
                    	// Changed for CR25
                    	res.setEtr(ETR_UNKNOWN);
                    }
                    	
                    res.setMessage(row.getMessage());
                    res.setCrewStatus(row.getCrewStatus());
                    count = 1;
                } else { // for records 2 onwards
                    ++count;
                    if ( count == 2 ) {
                        res.setSuburb2( row.getLocalityName() );
                    } else if ( count == 3 ) {
                        res.setSuburb3( row.getLocalityName() );
                    } else if ( count == 4 ) {
                        res.setSuburb4( row.getLocalityName() );
                    } else if ( count == 5 ) {
                        res.setSuburb5( row.getLocalityName() );
                        break;
                    }
                }
            }
        	if(logger.isInfoEnabled()) logger.info(String.format("UNE: exiting getOutagesByPostcode: postcode = %s, return=%s", pcode,res));
            return res;
        } catch(DataAccessException ex) {
            logger.error(String.format("DataAccessException thrown in UNE:getOutagesByPostcode: %s", ex.getMessage()));
            throw ex;
        } catch(Exception e) {
            logger.error(String.format("Exception (%s) thrown in UNE:getOutagesByPostcode: %s",e.getClass().getCanonicalName(),  e.getMessage()));
        	throw e;
        }
    }

    /**
     * This is HostRequest4.3; SP written by CHED
     * UNTESTED - awaiting sample NMIs from CHED.
     */
   public OutageByNMIResponseDTO getOutagesByNmi(String theNmi) {
        try {
            if (logger.isInfoEnabled()) logger.info(String.format("UNE: entering getOutagesByNmi: Nmi=[%s], StoredProc=[%s]",theNmi,outagesByNmiStoredProcName)); 
        	HR43StoredProcedure proc = new HR43StoredProcedure(
                    getJdbcTemplate().getDataSource(), outagesByNmiStoredProcName );

            Map results = proc.execute( theNmi );

            if (results == null || results.isEmpty()) {
            	if (logger.isInfoEnabled()) logger.info(String.format("UNE: exiting getOutagesByNmi: Not results returned for NMI=%s",theNmi));
            	return null;
            }
            Integer rowCount = (Integer)results.get("rowCount");
            if (logger.isDebugEnabled()) logger.debug("Outage records = " + rowCount);
            
            if ( rowCount != 1 ) {
            	logger.warn(String.format("UNE: exiting getOutagesByNmi: Mutlpe result rows returned for NMI=%s, rowCount=%s",theNmi,rowCount));
            	return null;
            }

            if (logger.isDebugEnabled()) logger.debug(String.format("Outage for NMI: %s, Results: %s", theNmi, results.toString()));
            
            OutageByNMIResponseDTO nmiRecord = new OutageByNMIResponseDTO();

            String streetName = (String) results.get("STREET_NAME");
            String streetType = (String) results.get("STREET_TYPE");
            String locality = (String) results.get("LOCALITY");
            String etr = (String) results.get("ETR");
            String etrUnkown = (String) results.get("ETRUNKNOWN");
            String message = (String) results.get("MESSAGE");
            String orderid = (String) results.get("ORDER_ID");
            String crewstatus = (String) results.get("CREW_STATUS");

            // Filling in the result
            nmiRecord.setStreetName(streetName);
            nmiRecord.setStreetType(streetType);
            nmiRecord.setSuburb(locality);
            nmiRecord.setEtr(etr);
            nmiRecord.setMessage(message);
            nmiRecord.setCrewStatus(crewstatus);

            if (logger.isInfoEnabled()) logger.info(String.format("UNE: exiting getOutagesByNmi: NmiRecord=%s",nmiRecord));
            return nmiRecord;
        } catch(DataAccessException ex) {
            logger.error(String.format("DataAccessException thrown in UNE Ivr Outage DAO: %s", ex.getMessage()));
            throw ex;
        }
    }


    protected static final class RecordMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            IvrOutageInfoRecord nmiRecordIvr = new IvrOutageInfoRecord();

            nmiRecordIvr.setOrderId(rs.getInt(1));
            nmiRecordIvr.setLocalityId(rs.getInt(2));
            nmiRecordIvr.setLocalityName(rs.getString(3));
            nmiRecordIvr.setPostcode(rs.getString(4));
            nmiRecordIvr.setMessage(rs.getString(5));
            nmiRecordIvr.setCrewStatus(rs.getString(6));
            nmiRecordIvr.setCustomersAffected(rs.getInt(7));
            nmiRecordIvr.setPlanned(rs.getInt(8));
            nmiRecordIvr.setEtr(rs.getTimestamp(9));
            nmiRecordIvr.setFaultMemo(rs.getString(10));
            nmiRecordIvr.setPoweronUpdate(rs.getInt(11));

            return nmiRecordIvr;
        }
    }

    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public void setOutagesByPostcodeStoredProcName(String outagesByPostcodeStoredProcName) {
        this.outagesByPostcodeStoredProcName = outagesByPostcodeStoredProcName;
    }

    public void setOutagesByPostcodeStoredProcDriverType(String outagesByPostcodeStoredProcDriverType) {
        this.outagesByPostcodeStoredProcDriverType = outagesByPostcodeStoredProcDriverType;
    }

    public void setOutagesByNmiStoredProcName(String outagesByNmiStoredProcName) {
        this.outagesByNmiStoredProcName = outagesByNmiStoredProcName;
    }

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

}
