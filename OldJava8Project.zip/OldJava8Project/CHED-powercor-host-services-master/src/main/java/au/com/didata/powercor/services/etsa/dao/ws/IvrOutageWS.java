package au.com.didata.powercor.services.etsa.dao.ws;

import au.com.didata.powercor.services.etsa.dao.IEtsaIvrOutageDao;
import au.com.didata.powercor.services.etsapos.dto.EtsaNmiOutageRecord;
import au.com.didata.powercor.services.etsapos.dto.EtsaOutageByNmiResponseDTO;
import au.com.didata.powercor.services.etsapos.dto.EtsaOutageByPostcodeResponseDTO;
import au.com.didata.powercor.services.etsapos.dto.EtsaPostcodeOutageRecord;
import au.com.didata.powercor.services.exceptions.NoResponseException;

import org.apache.log4j.Logger;

import java.rmi.RemoteException;
import javax.xml.rpc.ServiceException;
import org.apache.axis.client.*;
import org.apache.axis.types.URI.MalformedURIException;
import org.tempuri.*;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;



/**
 * Created by : Sam Chan
 * Date: 21/06/2012
 * 
 */

public class IvrOutageWS implements IEtsaIvrOutageDao {
	
    private static final Logger logger = Logger.getLogger(IvrOutageWS.class);
	public static final int SUCCESS_CODE = 0;
	public static final int ERROR_CODE = -1;
    
	private String userName;
	private String password;
	private String endPointAddress;
	
    // Default constructor
    IvrOutageWS () {
    	
    }
    
    IvrOutageWS ( String endPointAddress, String userName, String password) {
    	this.endPointAddress = endPointAddress;
    	this.userName = userName;
    	this.password = password;
    }
    
    private OutagesSoap createOutagesSoap() throws Exception {
        OutagesSoap etsaOutagesSoap = null;
    	OutagesLocator etsaOutagesLocator;
    	logger.debug("createOutagesSoap - Start ");
    	try {
    		etsaOutagesLocator = new OutagesLocator();
    		logger.debug("OutageSoapLocator set endpoint to = "+ this.endPointAddress);
    		etsaOutagesLocator.setOutagesSoapEndpointAddress( this.endPointAddress);    		
    		logger.debug("Call getOutagesSoap");

    		etsaOutagesSoap = etsaOutagesLocator.getOutagesSoap();
        	Stub stub = (Stub)etsaOutagesSoap;
        	logger.debug("createOutagesSoap - Set username / password ");
        	stub.setUsername(userName);
        	stub.setPassword(password);
        	logger.debug("createOutagesSoap - Done ");
        	return etsaOutagesSoap;
        	
    	} catch ( Exception ex) {
    		throw ex;
    	}   	
    }
    
    public void setEndPointAddress(String endPointAddress) {
    	this.endPointAddress = endPointAddress;
    }
    
    public void setUserName(String userName) {
    	this.userName = userName;
    }
    
    public void setPassword(String passWord) {
    	this.password = passWord;
    }
  
    public EtsaOutageByPostcodeResponseDTO getOutagesByPostcode(String pcode) throws Exception {

    	
       	final String itemIVR = "IVR";
       	final String itemEtr = "ETR";
     	final String itemEtrKnown = "ETRKNOWN";
       	final String itemStage = "STAGECODE";
       	final String itemSuburb = "SUBURBID";
       	final String itemReason = "REASONCODE";
       	final String itemRestoredStatus = "RESTOREDSTATUS";
    //   	List<String> suburbList = new ArrayList<String>();
       	
    	logger.debug("ETSA: getOutagesByPostcode(Postcode="+pcode+")");
    	
    	EtsaOutageByPostcodeResponseDTO postcodeOutageResponse = new EtsaOutageByPostcodeResponseDTO();		

    	postcodeOutageResponse.setErrorCode(SUCCESS_CODE);
    	
        try {
        	OutagesSoap etsaOutagesSoap = createOutagesSoap();
        	logger.debug("Call outagesByPostcode");
        	GetPostcodeOutagesResponseGetPostcodeOutagesResult outagesByPostcode = etsaOutagesSoap.getPostcodeOutages(pcode);
        	
        	if ( outagesByPostcode == null )
        	{
            	logger.debug("outagesByPostcode is null ");
            	throw new NoResponseException(ERROR_CODE, "No outages response message for Postcode: " + pcode);
            	// return res;
        	}
        	org.apache.axis.message.MessageElement[] msgElementArray = outagesByPostcode.get_any();
        	List<org.apache.axis.message.MessageElement> filteredElementList = null;
 
        	if ( msgElementArray == null ) {
            	logger.debug("msgElementArray is null");
            	throw new NoResponseException(ERROR_CODE, "No outages message elements for Postcode: " + pcode);
            	//return res;
        	}
        	int count = msgElementArray.length;
        	org.apache.axis.message.MessageElement msgElement;
        	
        	logger.debug("Return Message length="+count);
     
        	for ( int inx = 0; inx < count; inx=inx+1) {
        		msgElement = msgElementArray[inx];
        		filteredElementList =getMessageElementArray( filteredElementList,msgElement,itemIVR  );
        	}
    
        	if ( filteredElementList == null) {
            	logger.debug("filteredElementList is null");
            	throw new NoResponseException(ERROR_CODE, "No IVR element in response message for Postcode: " + pcode);
            	//return res;
        	} else {
        		logger.debug("Number of "+itemIVR+" element ="+filteredElementList.size());
        		
        		for ( int index=0; index < filteredElementList.size(); index++) {
        			org.apache.axis.message.MessageElement itemElement = filteredElementList.get(index);
        			Iterator<org.apache.axis.message.MessageElement> _1_Iterator = itemElement.getChildElements();
        			EtsaPostcodeOutageRecord record = new EtsaPostcodeOutageRecord();
        			while ( _1_Iterator.hasNext() ) {
            			org.apache.axis.message.MessageElement _1_Element = _1_Iterator.next();
                		String elementName = _1_Element.getName();
                		String elementValue = _1_Element.getValue();
            			logger.debug("Element ("+itemIVR+"): <"+elementName+">=<"+elementValue+">");
       		
            			if (record.getEtr() == null) {
        					if ( elementName.equalsIgnoreCase( itemEtr) ) {
        						record.setEtr(elementValue);
        					}
            			}
            			if (record.getEtrKnown() == null) {
        					if ( elementName.equalsIgnoreCase( itemEtrKnown) ) {
        						record.setEtrKnown(elementValue);
        					}
            			}
            			if (record.getStage() == null) {
        					if ( elementName.equalsIgnoreCase( itemStage) ) {
        						record.setStage(elementValue);
        					}
            			}
            			if (record.getReason() == null) {
        					if ( elementName.equalsIgnoreCase( itemReason) ) {
        						record.setReason(elementValue);
        					}
            			}
            			if (record.getRestoredStatus() == null) {
            				if ( elementName.equalsIgnoreCase(itemRestoredStatus) ) {
            					record.setRestoredStatus(elementValue);            				}
            			}
            			if ( elementName.equalsIgnoreCase( itemSuburb) ) {
            				record.setSuburb(elementValue);
            			}
            		} // End record
        			logger.debug(record.toString());
        			// Add record to list
        			postcodeOutageResponse.addRecord(record);
        		}
        	}
        		
        	postcodeOutageResponse.setErrorCode(SUCCESS_CODE);
        
    
        } 	catch (RemoteException ex) {
        		logger.error( "RemoteException = "+ex.getMessage());
        		throw ex;
        	}
        	catch (Exception ex) {
        		logger.error( ex.getMessage());
        		throw ex;
        	}
    	return postcodeOutageResponse;
    }
    
    public EtsaOutageByNmiResponseDTO getOutagesByNmi(String theNmi){

    	final String itemIVR = "IVR";
       	final String itemEtr = "ETR";
     	final String itemEtrKnown = "ETRKNOWN";
       	final String itemStage = "STAGECODE";
       	final String itemSuburb = "SUBURBID";
       	final String itemReason = "REASONCODE";
      
    	String elementName;
    	String elementValue;
    	
    	logger.debug("getOutagesByNMI(NMI="+theNmi+")");
    	

    	EtsaOutageByNmiResponseDTO nmiOutageResponse = new EtsaOutageByNmiResponseDTO();		
     	
    	nmiOutageResponse.setErrorCode(SUCCESS_CODE);
    	
        try {
        	OutagesSoap etsaOutagesSoap = createOutagesSoap();
        	logger.debug("Call outagesByNmi");
        	GetNMIOutageResponseGetNMIOutageResult outagesByNmi = etsaOutagesSoap.getNMIOutage(theNmi);
        	
        	if ( outagesByNmi == null )
        	{
            	logger.debug("outagesByNmi is null ");
            	throw new NoResponseException(ERROR_CODE, "No outages response message for NMI : " + theNmi);
            	// return res;
        	}
        	org.apache.axis.message.MessageElement[] msgElementArray = outagesByNmi.get_any();
        	List<org.apache.axis.message.MessageElement> filteredElementList = null;
 
        	if ( msgElementArray == null )
        	{
            	logger.debug("msgElementArray is null");
            	throw new NoResponseException(ERROR_CODE, "No outages message elements for NMI: " + theNmi);
            	//return res;
        	}
        	int count = msgElementArray.length;
        	org.apache.axis.message.MessageElement msgElement;
        	
        	logger.debug("Return Message length="+count);
     
        	for ( int inx = 0; inx < count; inx=inx+1) {
        		msgElement = msgElementArray[inx];
        		filteredElementList =getMessageElementArray( filteredElementList,msgElement,itemIVR  );
        	}
    
        	if ( filteredElementList == null) {
            	logger.debug("filteredElementList is null");
            	throw new NoResponseException(ERROR_CODE, "No IVR element in response message for NMI: " + theNmi);
            	//return res;
        	} else {
        		
        		logger.debug("Number of "+itemIVR+" element ="+filteredElementList.size());
        		
        		for ( int index=0; index < filteredElementList.size(); index++) {
        			EtsaNmiOutageRecord record = new EtsaNmiOutageRecord();
        			
        			org.apache.axis.message.MessageElement itemElement = filteredElementList.get(index);
        			Iterator<org.apache.axis.message.MessageElement> _1_Iterator = itemElement.getChildElements();
        			while ( _1_Iterator.hasNext() ) {
            			org.apache.axis.message.MessageElement _1_Element = _1_Iterator.next();
                		elementName = _1_Element.getName();
                		elementValue = _1_Element.getValue();
            			logger.debug("Element ("+itemIVR+"): <"+elementName+">=<"+elementValue+">");

            			if (record.getEtr() == null) {
        					if ( elementName.equalsIgnoreCase( itemEtr) ) {
        						record.setEtr(elementValue);
        					}
            			}
            			if (record.getEtrKnown() == null) {
        					if ( elementName.equalsIgnoreCase( itemEtrKnown) ) {
        						record.setEtrKnown(elementValue);
        					}
            			}
            			if (record.getStage() == null) {
        					if ( elementName.equalsIgnoreCase( itemStage) ) {
        						record.setStage(elementValue);
        					}
            			}
            			if (record.getReason() == null) {
        					if ( elementName.equalsIgnoreCase( itemReason) ) {
        						record.setReason(elementValue);
        					}
            			}
            			if ( elementName.equalsIgnoreCase( itemSuburb) ) {
            				record.setSuburb(elementValue);
            			}
        			} // End record
        			logger.debug(record.toString());
        			// Add record to list
        			nmiOutageResponse.addRecord(record);
        		}
        	}
        	nmiOutageResponse.setErrorCode(SUCCESS_CODE);
        }	catch (RemoteException ex) {
        		logger.error( "RemoteException = "+ex.getMessage());
        		nmiOutageResponse.setErrorCode(ERROR_CODE);
        	}
        	catch (Exception ex) {
        		logger.error( ex.getMessage());
        		nmiOutageResponse.setErrorCode(ERROR_CODE);
        	}

        return nmiOutageResponse;
    }
    
    private List<org.apache.axis.message.MessageElement> getMessageElementArray( List<org.apache.axis.message.MessageElement> msgElementList, org.apache.axis.message.MessageElement nodeElement, String elementKey) {

    	if ( nodeElement != null && elementKey != null  ) {
    	
    		if ( nodeElement.getName().equalsIgnoreCase(elementKey) ) {
    			if (msgElementList == null ) {
    				msgElementList = new ArrayList<org.apache.axis.message.MessageElement>();
    			}
    			msgElementList.add( nodeElement);
    		} else {
        		Iterator<org.apache.axis.message.MessageElement> _1_Iterator = nodeElement.getChildElements();
        		while ( _1_Iterator.hasNext() ) {
        			msgElementList = getMessageElementArray(msgElementList,_1_Iterator.next(),elementKey    );
     
        		}
    		}
    	}
    	return msgElementList;
    }
}
