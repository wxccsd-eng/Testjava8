package org.tempuri;

public class OutagesSoapProxy implements org.tempuri.OutagesSoap {
  private String _endpoint = null;
  private org.tempuri.OutagesSoap outagesSoap = null;
  
  public OutagesSoapProxy() {
    _initOutagesSoapProxy();
  }
  
  public OutagesSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initOutagesSoapProxy();
  }
  
  private void _initOutagesSoapProxy() {
    try {
      outagesSoap = (new org.tempuri.OutagesLocator()).getOutagesSoap();
      if (outagesSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)outagesSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)outagesSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (outagesSoap != null)
      ((javax.xml.rpc.Stub)outagesSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public org.tempuri.OutagesSoap getOutagesSoap() {
    if (outagesSoap == null)
      _initOutagesSoapProxy();
    return outagesSoap;
  }
  
  public org.tempuri.GetNMIOutageResponseGetNMIOutageResult getNMIOutage(java.lang.String NMI) throws java.rmi.RemoteException{
    if (outagesSoap == null)
      _initOutagesSoapProxy();
    return outagesSoap.getNMIOutage(NMI);
  }
  
  public org.tempuri.GetPostcodeOutagesResponseGetPostcodeOutagesResult getPostcodeOutages(java.lang.String postcode) throws java.rmi.RemoteException{
    if (outagesSoap == null)
      _initOutagesSoapProxy();
    return outagesSoap.getPostcodeOutages(postcode);
  }
  
  public org.tempuri.CurrentOutagesResponseCurrentOutagesResult currentOutages() throws java.rmi.RemoteException{
    if (outagesSoap == null)
      _initOutagesSoapProxy();
    return outagesSoap.currentOutages();
  }
  
  public org.tempuri.RestoredOutagesResponseRestoredOutagesResult restoredOutages() throws java.rmi.RemoteException{
    if (outagesSoap == null)
      _initOutagesSoapProxy();
    return outagesSoap.restoredOutages();
  }
  
  
}