/**
 * CurrentOutagesResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tempuri;

public class CurrentOutagesResponse  implements java.io.Serializable {
    private org.tempuri.CurrentOutagesResponseCurrentOutagesResult currentOutagesResult;

    public CurrentOutagesResponse() {
    }

    public CurrentOutagesResponse(
           org.tempuri.CurrentOutagesResponseCurrentOutagesResult currentOutagesResult) {
           this.currentOutagesResult = currentOutagesResult;
    }


    /**
     * Gets the currentOutagesResult value for this CurrentOutagesResponse.
     * 
     * @return currentOutagesResult
     */
    public org.tempuri.CurrentOutagesResponseCurrentOutagesResult getCurrentOutagesResult() {
        return currentOutagesResult;
    }


    /**
     * Sets the currentOutagesResult value for this CurrentOutagesResponse.
     * 
     * @param currentOutagesResult
     */
    public void setCurrentOutagesResult(org.tempuri.CurrentOutagesResponseCurrentOutagesResult currentOutagesResult) {
        this.currentOutagesResult = currentOutagesResult;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CurrentOutagesResponse)) return false;
        CurrentOutagesResponse other = (CurrentOutagesResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.currentOutagesResult==null && other.getCurrentOutagesResult()==null) || 
             (this.currentOutagesResult!=null &&
              this.currentOutagesResult.equals(other.getCurrentOutagesResult())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCurrentOutagesResult() != null) {
            _hashCode += getCurrentOutagesResult().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CurrentOutagesResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", ">CurrentOutagesResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currentOutagesResult");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "CurrentOutagesResult"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", ">>CurrentOutagesResponse>CurrentOutagesResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
