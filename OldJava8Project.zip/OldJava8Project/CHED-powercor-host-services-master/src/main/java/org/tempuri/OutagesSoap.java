/**
 * OutagesSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tempuri;

public interface OutagesSoap extends java.rmi.Remote {

    /**
     * service for returning a NMI Outage
     */
    public org.tempuri.GetNMIOutageResponseGetNMIOutageResult getNMIOutage(java.lang.String NMI) throws java.rmi.RemoteException;

    /**
     * service for returning suburb Outages
     */
    public org.tempuri.GetPostcodeOutagesResponseGetPostcodeOutagesResult getPostcodeOutages(java.lang.String postcode) throws java.rmi.RemoteException;

    /**
     * Current outages
     */
    public org.tempuri.CurrentOutagesResponseCurrentOutagesResult currentOutages() throws java.rmi.RemoteException;

    /**
     * Restored outages for the amount of time configured in setting
     * table, setting code
     */
    public org.tempuri.RestoredOutagesResponseRestoredOutagesResult restoredOutages() throws java.rmi.RemoteException;
}
